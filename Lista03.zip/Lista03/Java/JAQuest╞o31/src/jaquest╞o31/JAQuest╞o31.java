package jaquestão31;
import java.util.Scanner;

public class JAQuestão31 {
public class ContagemLetras {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nEste programa lê textos por linha. Após exibir o texto, o programa determina a quantidade de uma determinada letra digitada!");
        System.out.printf("\nDigite um texto (até 999 caracteres): ");
        scanner.nextLine(); // Limpa o buffer do teclado
        String texto = scanner.nextLine();

        System.out.printf("\nTexto digitado: " + texto);

        System.out.printf("\nDigite uma letra para contar sua ocorrência no texto: ");
        char letra = scanner.next().charAt(0);

        int contador = 0;
        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == letra) {
                contador++;
            }
        }

        System.out.printf("\nA letra '" + letra + "' ocorre " + contador + " vezes no texto.");
        System.out.printf("\nObrigado por utilizar nosso programa!\n");
        }
    }
}