package jaquestão17;
import java.util.Scanner;

public class JAQuestão17 {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int i, j, somaDiagonal = 0, somaAbaixoDaDiagonal = 0;

        System.out.println("\nEste programa carrega e imprime uma matriz A 10x10 e determina a soma dos elementos abaixo da diagonal principal da matriz, incluindo os elementos da própria diagonal!\n");
        System.out.println("Informe os elementos da matriz A!");

        int[][] A = new int[10][10];
        for (i = 0; i < 10; i++) {
            for (j = 0; j < 10; j++) {
                System.out.printf("Informe o elemento na posição A[%d][%d]: ", i, j);
                A[i][j] = leia.nextInt();
            }
        }
        System.out.println("\n");

        System.out.println("A = ");
        for (i = 0; i < 10; i++) {
            System.out.println();
            for (j = 0; j < 10; j++) {
                System.out.printf(" %d ", A[i][j]);
            }
        }

        System.out.println("\n");

        for (i = 0; i < 10; i++) {
            for (j = 0; j < 10; j++) {
                if (i == j) {
                    somaDiagonal = somaDiagonal + A[i][j];
                } else if (i > j) {
                    somaAbaixoDaDiagonal = somaAbaixoDaDiagonal + A[i][j];
                }
            }
        }

        System.out.println("\nA soma dos elementos abaixo da diagonal principal é de: " + somaAbaixoDaDiagonal);
        System.out.println("A soma dos elementos da diagonal principal é de: " + somaDiagonal);

        System.out.println("\nObrigado por utilizar nosso programa!\n");
    }
}