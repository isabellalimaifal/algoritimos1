package jaquestão03;
import java.util.Scanner;

public class JAQuestão03 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanhoA, tamanhoB;
        System.out.printf("\nEste programa determina 2.(3.A + 5.B), A e B, caso seja possível.!\n");

        // Solicita o tamanho do vetor A
        System.out.printf("\nDigite o tamanho do vetor A: ");
        tamanhoA = scanner.nextInt();

        // Solicita o tamanho do vetor B
        System.out.printf("\nDigite o tamanho do vetor B: ");
        tamanhoB = scanner.nextInt();

        // Declare os vetores A, B e Resultado com os tamanhos especificados
        int[] A = new int[tamanhoA];
        int[] B = new int[tamanhoB];
        int[] Resultado = new int[tamanhoA];

        // Solicita os elementos do vetor A
        System.out.printf("\nDigite os elementos do vetor A: \n");
        for (int i = 0; i < tamanhoA; i++) {
            System.out.printf("Elemento [%d]: ", i);
            A[i] = scanner.nextInt();
        }

        // Solicita os elementos do vetor B
        System.out.printf("\nDigite os elementos do vetor B: \n");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("Elemento [%d]: ", i);
            B[i] = scanner.nextInt();
        }

        System.out.printf("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime os vetores A e B
        System.out.printf("\nVetor A: [");
        for (int i = 0; i < tamanhoA; i++) {
            System.out.printf("%d", A[i]);
            if (i < tamanhoA - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        System.out.printf("\nVetor B: [");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("%d", B[i]);
            if (i < tamanhoB - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        // Verifica se os vetores têm o mesmo tamanho para calcular
        if (tamanhoA != tamanhoB) {
            System.out.printf("\nOs vetores A e B não têm o mesmo tamanho. Não é possível calcular a soma.\n");
        } else {
            // Calcula os resultados e armazena em vetor Resultado
            for (int i = 0; i < tamanhoA; i++) {
                Resultado[i] = 2 * (3 * A[i] + 5 * B[i]);
            }

            // Imprime o vetor de resultados
            System.out.printf("\nVetor C: [");
            for (int i = 0; i < tamanhoA; i++) {
                System.out.printf("%d", Resultado[i]);
                if (i < tamanhoA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nObrigado por utilizar nosso programa!\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    private static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    private static void pressAnyKeyToContinue() {
        System.out.printf("Pressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}