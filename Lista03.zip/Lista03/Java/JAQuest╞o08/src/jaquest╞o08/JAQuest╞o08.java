package jaquestão08;
import java.util.Scanner;

public class JAQuestão08 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int maxD = 100; // Tamanho máximo das matrizes
        System.out.printf("\nEste programa permite a soma de duas matrizes (A e B) e, caso seja possível realizar a operação, determina a matriz transposta da matriz resultante, bem como a soma de seus elementos!\n");

        // Solicita o tamanho da matriz A
        System.out.printf("\nDigite o número de linhas da matriz A: ");
        int linhasA = scanner.nextInt();
        System.out.printf("\nDigite o número de colunas da matriz A: ");
        int colunasA = scanner.nextInt();

        // Solicita o tamanho da matriz B
        System.out.printf("\nDigite o número de linhas da matriz B: ");
        int linhasB = scanner.nextInt();
        System.out.printf("\nDigite o número de colunas da matriz B: ");
        int colunasB = scanner.nextInt();

        // Verifica se as matrizes podem ser somadas
        if (linhasA != linhasB || colunasA != colunasB) {
            System.out.printf("\nAs matrizes A e B não podem ser somadas devido a tamanhos diferentes.\n");
            return;
        }

        // Declara as matrizes A, B e a matriz resultante C
        int[][] matrizA = new int[maxD][maxD];
        int[][] matrizB = new int[maxD][maxD];
        int[][] matrizC = new int[maxD][maxD];

        // Solicita os elementos da matriz A
        System.out.printf("\nDigite os elementos da matriz A (" + linhasA + " x " + colunasA + "): \n\n");
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                System.out.printf("\n\n Elemento [" + i + "][" + j + "]: ");
                matrizA[i][j] = scanner.nextInt();
            }
        }

        // Solicita os elementos da matriz B
        System.out.printf("\nDigite os elementos da matriz B (" + linhasB + " x " + colunasB + "):\n\n");
        for (int i = 0; i < linhasB; i++) {
            for (int j = 0; j < colunasB; j++) {
                System.out.printf("\n\nElemento [" + i + "][" + j + "]: ");
                matrizB[i][j] = scanner.nextInt();
            }
        }

        // Realiza a soma das matrizes A e B e armazena o resultado em C
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                matrizC[i][j] = matrizA[i][j] + matrizB[i][j];
            }
        }

        // Calcula a transposta da matriz resultante
        int[][] matrizTransposta = new int[maxD][maxD];
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                matrizTransposta[j][i] = matrizC[i][j];
            }
        }

        // Calcula a soma dos elementos da matriz resultante
        int somaElementos = 0;
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                somaElementos += matrizC[i][j];
            }
        }

        System.out.println("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime as matrizes A, B, C e a transposta da matriz C
        System.out.printf("\nMatriz A: ");
        for (int i = 0; i < linhasA; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasA; j++) {
                System.out.print(matrizA[i][j]);
                if (j < colunasA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nMatriz B: ");
        for (int i = 0; i < linhasB; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasB; j++) {
                System.out.print(matrizB[i][j]);
                if (j < colunasB - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nMatriz Resultante C: ");
        for (int i = 0; i < linhasA; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasA; j++) {
                System.out.print(matrizC[i][j]);
                if (j < colunasA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nTransposta da Matriz C: ");
        for (int i = 0; i < colunasA; i++) {
            System.out.printf("[");
            for (int j = 0; j < linhasA; j++) {
                System.out.print(matrizTransposta[i][j]);
                if (j < linhasA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nSoma dos elementos da matriz resultante: " + somaElementos + "\n");
        System.out.printf("\n\nObrigado por utilizar nosso programa!\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.printf("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.printf("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}