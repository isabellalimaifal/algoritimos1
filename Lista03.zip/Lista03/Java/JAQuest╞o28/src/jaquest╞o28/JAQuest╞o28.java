package jaquestão28;
import java.util.Scanner;

public class JAQuestão28 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in); 
        int maxfrase = 4;
        int maxcaracter = 10;
        String frases[] = new String[maxfrase];
        int numFrases = 0;

        System.out.printf("\n\nEste programa lê várias frases e as imprime. Em seguida, o programa lê uma frase e determina se a mesma faz parte do conjunto de frases anteriormente ou não!");
        System.out.printf("\n\nDigite várias frases:\n");

        while (numFrases < maxfrase) {
            System.out.printf("Frase %d: ", numFrases + 1);
            frases[numFrases] = scanner.nextLine();
            numFrases++;
        }

        System.out.printf("\n\nFrases digitadas:\n");

        for (int i = 0; i < numFrases; i++) {
            System.out.printf("%d: %s\n", i + 1, frases[i]);
        }

        String fraseVerificar;
        System.out.printf("\n\nDigite a frase a ser verificada: ");
        fraseVerificar = scanner.nextLine();

        int encontrada = 0;
        for (int i = 0; i < numFrases; i++) {
            if (fraseVerificar.equals(frases[i])) {
                encontrada = 1;
                break;
            }
        }

        if (encontrada == 1) {
            System.out.printf("\n\nA frase faz parte do conjunto de frases lidas!");
        } else {
            System.out.printf("\n\nA frase não faz parte do conjunto de frases lidas!");
        }

        System.out.printf("\nObrigado por utilizar nosso programa!");
    }
}