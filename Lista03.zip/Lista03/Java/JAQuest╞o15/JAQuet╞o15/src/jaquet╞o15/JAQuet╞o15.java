/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jaquetão15;

import java.util.Scanner;

public class JAQuetão15 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("Esse programa possibilita o usuário jogar xadrez.");
        System.out.print("Digite o número de rodadas: ");
        int rodadas = scanner.nextInt();

        int[][] equipes = new int[5][rodadas];
        int[] idades = new int[5];
        int[] pontuacoes = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite a idade do competidor " + (i + 1) + ": ");
            idades[i] = scanner.nextInt();
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < rodadas; j++) {
                System.out.print("Digite a pontuação da equipe " + (i + 1) + " na rodada " + (j + 1) + " (0, 1 ou 3): ");
                equipes[i][j] = scanner.nextInt();

                if (equipes[i][j] != 0 && equipes[i][j] != 1 && equipes[i][j] != 3) {
                    System.out.println("Pontuação inválida! Use 0, 1 ou 3.");
                    j--;
                }
            }
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < rodadas; j++) {
                pontuacoes[i] += equipes[i][j];
            }
        }

        int equipeVencedora = 0;

        for (int i = 1; i < 5; i++) {
            if (pontuacoes[i] > pontuacoes[equipeVencedora]) {
                equipeVencedora = i;
            }
        }

        System.out.println("\nClassificação Final:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Equipe " + (i + 1) + " - Pontuação Total: " + pontuacoes[i]);
            if (i == equipeVencedora) {
                System.out.println(" (Equipe Vencedora)");
            } else {
                System.out.println();
            }
        }

        scanner.close();
    }
} 
  