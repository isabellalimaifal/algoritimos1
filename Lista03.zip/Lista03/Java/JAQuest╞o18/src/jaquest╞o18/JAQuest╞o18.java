package jaquestão18;
import java.util.Scanner;

public class JAQuestão18 {

    public static void main(String[] args) {
         Scanner leia = new Scanner(System.in);
         int i, j, diagonal = 1, superior = 1, inferior = 1;

        System.out.printf("Este programa carrega e imprime uma matriz A 5x5 é informa de acordo com a matriz que foi digitada se a diagonal dela é triangular inferior ou superior!");
        System.out.printf("\n\nInforme os elementos da matriz A!");

        int[][] A = new int[5][5];

        for (i = 0; i < 5; i++) {
            for (j = 0; j < 5; j++) {
                System.out.printf("\n\nInforme o elemento na posição A[" + i + "][" + j + "]: ");
                A[i][j] = leia.nextInt();
            }
        }
        
        leia.close();

        System.out.printf("\n\n\n");

        System.out.printf("\n\nA = \n");
        for (i = 0; i < 5; i++) {
            System.out.println();
            for (j = 0; j < 5; j++) {
                System.out.printf(" " + A[i][j] + " ");
            }
        }

        for (i = 0; i < 5; i++) {
            for (j = 0; j < 5; j++) {
                if (i != j && A[i][j] != 0) {
                    diagonal = 0;
                    if (i < j) {
                        inferior = 0;
                    } else if (i > j) {
                        superior = 0;
                    }
                }
            }
        }

        if (diagonal == 1) {
            System.out.printf("\n\nA matriz é diagonal!\n\n");
        } else if (inferior == 1) {
            System.out.printf("\n\nA matriz é triangular inferior!\n\n");
        } else if (superior == 1) {
            System.out.printf("\n\nA matriz é triangular superior!\n\n");
        } else {
            System.out.printf("\n\nA matriz não é diagonal, superior nem triangular inferior!\n\n");
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!\n\n");
    }
}