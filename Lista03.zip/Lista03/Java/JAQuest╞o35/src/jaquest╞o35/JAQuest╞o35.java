package jaquestão35;
import java.util.Scanner;

public class JAQuestão35 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int linhas, colunas;
        System.out.printf ("\n\nEste programa alimenta uma matriz qualquer da forma (A * B) * C, caso possível. Em seguida, caso possível, o programa deve somar os elementos da diagonal principal e da diagonal secundária. Além disso, o programa deve determinar a diferença entre as somas dos elementos da diagonal principal e da diagonal secundária!");
        System.out.printf ("\n\nDigite o número de linhas da matriz: ");
        linhas = scanner.nextInt();
        System.out.printf ("\n\nDigite o número de colunas da matriz: ");
        colunas = scanner.nextInt();

        if (linhas % 3 == 0 && colunas % 3 == 0) {
            int[][] matriz = new int[linhas][colunas];
            System.out.printf ("\n\nDigite os elementos da matriz: ");
            for (int i = 0; i < linhas; i++) {
                for (int j = 0; j < colunas; j++) {
                    matriz[i][j] = scanner.nextInt();
                }
            }

            int somaDiagonalPrincipal = 0;
            int somaDiagonalSecundaria = 0;
            for (int i = 0; i < linhas; i++) {
                for (int j = 0; j < colunas; j++) {
                    if (i == j) {
                        somaDiagonalPrincipal += matriz[i][j];
                    }
                    if (i + j == linhas - 1) {
                        somaDiagonalSecundaria += matriz[i][j];
                    }
                }
            }
            int diferenca = Math.abs(somaDiagonalPrincipal - somaDiagonalSecundaria); // Usando Math.abs para obter o valor absoluto da diferença
            System.out.printf("\n\nSoma da diagonal principal: " + somaDiagonalPrincipal);
            System.out.printf("\n\nSoma da diagonal secundária: " + somaDiagonalSecundaria);
            System.out.printf("\n\nDiferença entre as somas: " + diferenca);
        } else {
            System.out.printf("\n\nNão é possível criar uma matriz (A * B) * C com as dimensões fornecidas!");
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!");
    }   
}