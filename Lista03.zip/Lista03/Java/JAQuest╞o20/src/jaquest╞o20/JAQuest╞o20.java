package jaquestão20;
import java.util.Scanner;

public class JAQuestão20 {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int linhas, colunas;
        char letra;
        int contador = 0;

        System.out.printf("\n\nEste programa informa a quantidade de vezes que uma letra é encontrada na matriz.\n");
        System.out.printf("\n\nInforme a quantidade de linhas: ");
        linhas = leia.nextInt();

        System.out.printf("\nInforme a quantidade de colunas: ");
        colunas = leia.nextInt();

        char[][] matriz = new char[linhas][colunas];

   
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.printf("\nDigite o caracter da matriz["+i+"]["+j+"]:");
                matriz[i][j] = leia.next().charAt(0);
            }
        }



        System.out.print("\nInforme a letra que deverá ser encontrada: ");
        letra = leia.next().charAt(0);

        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (matriz[i][j] == letra) {
                    contador++;
                }
            }
        }

        System.out.printf("\nA letra '" + letra + "' foi encontrada " + contador + " vezes na matriz.\n");
        System.out.printf("\nObrigado por utilizar o nosso programa!\n");
        leia.close();
    }
    
}