package jaquestão05;
import java.util.Scanner;

public class JAQuestão05 {

    // Função para ordenar um vetor em ordem crescente (método da seleção)
    static void ordenarCrescente(int vetor[], int tamanho) {
        for (int i = 0; i < tamanho - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < tamanho; j++) {
                if (vetor[j] < vetor[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                int temp = vetor[i];
                vetor[i] = vetor[minIndex];
                vetor[minIndex] = temp;
            }
        }
    }

    // Função para ordenar um vetor em ordem decrescente (método da seleção invertido)
    static void ordenarDecrescente(int vetor[], int tamanho) {
        for (int i = 0; i < tamanho - 1; i++) {
            int maxIndex = i;
            for (int j = i + 1; j < tamanho; j++) {
                if (vetor[j] > vetor[maxIndex]) {
                    maxIndex = j;
                }
            }
            if (maxIndex != i) {
                int temp = vetor[i];
                vetor[i] = vetor[maxIndex];
                vetor[maxIndex] = temp;
            }
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanho;
        System.out.printf("\n\nEste programa lê um vetor inteiro e oferece uma maneira conveniente de encontrar a posição de um número na estrutura de dados em diferentes ordens (crescente e decrescente) e permite que você visualize a estrutura organizada de acordo com essas ordens!\n");

        // Solicita o tamanho do vetor
        System.out.printf("\nDigite o tamanho do vetor: ");
        tamanho = scanner.nextInt();

        // Declare o vetor com o tamanho especificado
        int[] vetor = new int[tamanho];

        // Solicita os elementos do vetor
        System.out.printf("\nDigite os elementos do vetor\n");
        for (int i = 0; i < tamanho; i++) {
            System.out.printf("Elemento [%d] ", i);
            vetor[i] = scanner.nextInt();
        }

        // Imprime o vetor na ordem original
        System.out.printf("\nVetor Original: [");
        for (int i = 0; i < tamanho; i++) {
            System.out.printf("%d", vetor[i]);
            if (i < tamanho - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]%n");

        // Busca um número na estrutura
        int numero;
        System.out.printf("\nDigite o número que deseja buscar: ");
        numero = scanner.nextInt();

        // Procura a posição do número quando o vetor está em ordem crescente
        int posicaoCrescente = -1;
        int[] vetorCrescente = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            vetorCrescente[i] = vetor[i];
        }
        ordenarCrescente(vetorCrescente, tamanho); // Ordena em ordem crescente

        for (int i = 0; i < tamanho; i++) {
            if (vetorCrescente[i] == numero) {
                posicaoCrescente = i;
                break;
            }
        }

        System.out.printf("\n\n\n");
        clearConsole();

        // Imprime o vetor em ordem crescente
        System.out.printf("\nVetor Crescente: [");
        for (int i = 0; i < tamanho; i++) {
            System.out.printf("%d", vetorCrescente[i]);
            if (i < tamanho - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]");

        // Procura a posição do número quando o vetor está em ordem decrescente
        int posicaoDecrescente = -1;
        int[] vetorDecrescente = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            vetorDecrescente[i] = vetor[i];
        }
        ordenarDecrescente(vetorDecrescente, tamanho); // Ordena em ordem decrescente

        for (int i = 0; i < tamanho; i++) {
            if (vetorDecrescente[i] == numero) {
                posicaoDecrescente = i;
                break;
            }
        }

        // Imprime o vetor em ordem decrescente
        System.out.printf("\nVetor Decrescente: [");
        for (int i = 0; i < tamanho; i++) {
            System.out.printf("%d", vetorDecrescente[i]);
            if (i < tamanho - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        // Imprime a posição do número nas duas ordens
        if (posicaoCrescente != -1) {
            System.out.printf("\nPosição do número %d em ordem crescente: %d", numero, posicaoCrescente);
        } else {
            System.out.printf("\nO número %d não foi encontrado em ordem crescente.", numero);
        }
        if (posicaoDecrescente != -1) {
            System.out.printf("\nPosição do número %d em ordem decrescente: %d", numero, posicaoDecrescente);
        } else {
            System.out.printf("\nnO número %d não foi encontrado em ordem decrescente.\n", numero);
        }
        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }

    // Função para limpar o console
    static void clearConsole() {
         try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.printf("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }   
}