package jaquestão10;
import java.util.Scanner;

public class JAQuestão10 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int maxD = 100; // Tamanho máximo da matriz
        clearConsole();
        System.out.printf("\nEste programa permite inserir uma matriz A de números inteiros e, em seguida, realizar a busca de um número inteiro específico na matriz. Se houver repetições desse número na matriz, o programa identificará a posição de cada repetição!\n");
     
        // Solicita o tamanho da matriz
        System.out.printf("\nDigite o número de linhas da matriz A: ");
        int linhas = scanner.nextInt();
        System.out.printf("\nDigite o número de colunas da matriz A: ");
        int colunas = scanner.nextInt();

        // Declara a matriz
        int[][] matriz = new int[maxD][maxD];

        // Solicita os elementos da matriz com a formatação "Elemento : [i][j]"
        System.out.printf("\nDigite os elementos da matriz A (" + linhas + " x " + colunas + "):");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.printf("\nElemento : [" + i + "][" + j + "] : ");
                matriz[i][j] = scanner.nextInt();
            }
        }

        // Solicita o número a ser buscado na matriz
        System.out.printf("\nDigite o número que deseja buscar na matriz A: ");
        int numero = scanner.nextInt();

        System.out.printf("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Realiza a busca e identifica a posição de cada repetição do número
        int encontrado = 0;
        System.out.printf("\nPosições do número " + numero + " na matriz A:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (matriz[i][j] == numero) {
                    System.out.printf("[" + (i + 1) + "][" + (j + 1) + "]\n");
                    encontrado++;
                }
            }
        }

        if (encontrado == 0) {
            System.out.printf("\nO número " + numero + " não foi encontrado na matriz A.");
        }

        // Imprime os elementos informados pelo usuário em formato de coluna e linha com colchetes
        System.out.printf("\nMatriz A informada pelo usuário :");
        for (int i = 0; i < linhas; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunas; j++) {
                System.out.print(matriz[i][j]);
                if (j < colunas - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }
        System.out.printf("\n\nObrigado por utilizar nosso programa!\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.printf("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}