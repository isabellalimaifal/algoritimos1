package jaquestão42;
import java.util.Scanner;

public class JAQuestão42 {
    
public class VerificarComutatividadeMatrizes {
    public static final int maxL = 100;
    public static final int maxC = 100;

    public static void imprimirMatriz(int[][] matriz, int linhas, int colunas) {
        for (int i = 0; i < linhas; ++i) {
            System.out.printf("[ ");
            for (int j = 0; j < colunas; ++j) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.printf("]");
        }
    }
    

    public static boolean comutam(int[][] matrizA, int[][] matrizB, int linhas, int colunas) {
        // Verifica se A * B é igual a B * A
        int[][] resultadoAB = new int[maxL][maxC];
        int[][] resultadoBA = new int[maxL][maxC];

        for (int i = 0; i < linhas; ++i) {
            for (int j = 0; j < colunas; ++j) {
                resultadoAB[i][j] = 0;
                resultadoBA[i][j] = 0;

                for (int k = 0; k < colunas; ++k) {
                    resultadoAB[i][j] += matrizA[i][k] * matrizB[k][j];
                    resultadoBA[i][j] += matrizB[i][k] * matrizA[k][j];
                }
            }
        }

        // Verifica se as matrizes A * B e B * A são iguais
        for (int i = 0; i < linhas; ++i) {
            for (int j = 0; j < colunas; ++j) {
                if (resultadoAB[i][j] != resultadoBA[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }   

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        System.out.printf("\n\nEste programa verifica se duas matrizes A e B comutam!\n");
        System.out.printf("\nInforme o número de linhas e colunas das matrizes: ");
        int linhas = scanner.nextInt();
        int colunas = scanner.nextInt();

        int[][] matrizA = new int[maxL][maxC];
        int[][] matrizB = new int[maxL][maxC];

        System.out.printf("\nInforme os elementos da matriz A: ");
        for (int i = 0; i < linhas; ++i) {
            for (int j = 0; j < colunas; ++j) {
                System.out.printf("\nMatriz A[" + i + "][" + j + "]: ");
                matrizA[i][j] = scanner.nextInt();
            }
        }

        System.out.printf("\nInforme os elementos da matriz B: ");
        for (int i = 0; i < linhas; ++i) {
            for (int j = 0; j < colunas; ++j) {
                System.out.printf("\nMatriz B[" + i + "][" + j + "]: ");
                matrizB[i][j] = scanner.nextInt();
            }
        }

        System.out.printf("\nMatriz A: ");
        imprimirMatriz(matrizA, linhas, colunas);

        System.out.printf("\nMatriz B: ");
        imprimirMatriz(matrizB, linhas, colunas);

        if (comutam(matrizA, matrizB, linhas, colunas)) {
            System.out.printf("\nAs matrizes A e B comutam.\n");
        } else {
            System.out.printf("\nAs matrizes A e B não comutam.\n");
        }

        System.out.printf("\nObrigado por utilizar nosso programa!");
        } 
    }
}