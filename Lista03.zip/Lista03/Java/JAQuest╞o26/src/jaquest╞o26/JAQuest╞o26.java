package jaquestão26;
import java.util.Scanner;

public class JAQuestão26 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\n\nEste programa realiza a multiplicação de duas matrizes quadradas de ordem n, imprime as duas matrizes originais, a matriz resultado e carrega um array com os elementos da diagonal secundária!");
        System.out.printf("\n\nInforme a ordem da matriz quadrada: ");
        int n = scanner.nextInt();

        int[][] A = new int[n][n];
        int[][] B = new int[n][n];
        int[][] C = new int[n][n];

        System.out.printf("\n\nInforme os elementos da matriz A: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                A[i][j] = scanner.nextInt();
            }
        }

        System.out.printf("\n\nInforme os elementos da matriz B: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                B[i][j] = scanner.nextInt();
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                C[i][j] = 0;
                for (int k = 0; k < n; k++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        System.out.printf("\n\nMatriz A: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(A[i][j] + " ");
            }
            System.out.println();
        }

        System.out.printf("\n\nMatriz B:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf(B[i][j] + " ");
            }
            System.out.println();
        }

        System.out.printf("\n\nMatriz Resultado (C): ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(C[i][j] + " ");
            }
            System.out.println();
        }

        int[] diagonalSecundaria = new int[n];
        for (int i = 0; i < n; i++) {
            diagonalSecundaria[i] = C[i][n - 1 - i];
        }
        
        System.out.printf("\n\nElementos da diagonal secundária de C: ");
        for (int i = 0; i < n; i++) {
            System.out.printf(diagonalSecundaria[i] + " ");
        }
        System.out.printf("\n\nObrigado por utilizar nosso programa!");
    }
}