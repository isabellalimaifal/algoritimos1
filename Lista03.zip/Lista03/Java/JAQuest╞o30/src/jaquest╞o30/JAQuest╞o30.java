package jaquestão30;
import java.util.Scanner;

public class JAQuestão30 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\n\nEste programa alimenta uma matriz de números aleatórios, imprime seus elementos e o resultado da soma dos elementos com índice j é par!");

        int linhas = 4, colunas = 5;
        int[][] matriz = new int[linhas][colunas];

        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.printf("\n\nDigite o valor para matriz[" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }

        System.out.printf("\n\nMatriz: ");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }

        int soma = 0;
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j += 2) { // pares do j
                soma += matriz[i][j];
            }
        }

        System.out.printf("\n\nSoma dos elementos com índice j par: " + soma);
        System.out.printf("\n\nObrigado por utilizar nosso programa!");
    }   
}