package jaquestão12;
import java.util.Scanner;

public class JAQuestão12 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int maxPalavras = 100;
        String[] palavras = new String[maxPalavras];
        int n;
        System.out.printf("\n\nEste programa lê e armazena n palavras e, depois, após digitar uma palavra qualquer, o programa faz a busca da palavra digitada entre as palavras armazenadas!\n");
        System.out.printf("Informe o número de palavras a serem inseridas: ");
        n = scanner.nextInt();
        scanner.nextLine();

        // Ler e armazenar as palavras
        for (int i = 0; i < n; ++i) {
            System.out.printf("Informe a palavra #" + (i + 1) + ": ");
            palavras[i] = scanner.nextLine();
        }

        
        System.out.printf("\nInforme a palavra a ser procurada: ");
        String palavraProcurada = scanner.nextLine();

        int ultimaPosicao = -1; // Inicializar a última posição como -1 (indicando que não foi encontrada)
        int quantidadeRepeticoes = 0;
        for (int i = 0; i < n; ++i) {
            if (palavras[i].equals(palavraProcurada)) {
                ultimaPosicao = i;
                quantidadeRepeticoes++;
            }
        }

        System.out.printf("\n\n\n");
        scanner.nextLine(); 

        if (ultimaPosicao != -1) {
            System.out.printf("A palavra '" + palavraProcurada + "' foi encontrada pela última vez na posição " + (ultimaPosicao + 1) + ".");
            System.out.printf("Ela aparece " + quantidadeRepeticoes + " vez(es) na lista.");
        } else {
            System.out.printf("A palavra '" + palavraProcurada + "' não foi encontrada na lista.");
        }

        System.out.printf("\nObrigado por utilizar nosso programa!");
        scanner.nextLine(); 
    }
}