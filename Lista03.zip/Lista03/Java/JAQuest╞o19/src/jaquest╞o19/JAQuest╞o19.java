package jaquestão19;
import java.util.Scanner;

public class JAQuestão19 {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int i, j, linhasA, colunasA;

        System.out.printf("Este programa carrega e imprime uma matriz A[i][j] e determina a soma de cada linha e coluna.\n");
        System.out.printf("\n\nInforme a quantidade de linhas: ");
        linhasA = leia.nextInt();
        System.out.printf("\n\nInforme a quantidade de colunas: ");
        colunasA = leia.nextInt();

        System.out.printf("\n\nInforme os elementos da matriz A:\n");

        int[][] A = new int[linhasA][colunasA];
        int[] somaLinhas = new int[linhasA];
        int[] somaColunas = new int[colunasA];

        for (i = 0; i < linhasA; i++) {
            for (j = 0; j < colunasA; j++) {
                System.out.printf("Informe o elemento na posição A[" + i + "][" + j + "]: ");
                A[i][j] = leia.nextInt();
            }
        }

        System.out.printf("\nMatriz A:\n");
        for (i = 0; i < linhasA; i++) {
            for (j = 0; j < colunasA; j++) {
                System.out.print(A[i][j] + " ");
            }
            System.out.println();
        }

        for (i = 0; i < linhasA; i++) {
            for (j = 0; j < colunasA; j++) {
                somaLinhas[i] += A[i][j];
                somaColunas[j] += A[i][j];
            }
        }

        System.out.printf("\nSoma das Linhas:\n");
        for (i = 0; i < linhasA; i++) {
            System.out.printf("Linha " + (i + 1) + ": " + somaLinhas[i]);
        }

        System.out.printf("\nSoma das Colunas:\n");
        for (j = 0; j < colunasA; j++) {
            System.out.printf("Coluna " + (j + 1) + ": " + somaColunas[j]);
        }

        System.out.println("\nObrigado por utilizar o nosso programa.\n");
        leia.close();

    }
    
}