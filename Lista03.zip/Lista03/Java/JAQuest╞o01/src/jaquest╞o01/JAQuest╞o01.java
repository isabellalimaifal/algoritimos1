package jaquestão01;
import java.util.Scanner;

public class JAQuestão01 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nEste programa lê os dados de três vetores de números inteiros e imprime o resultado da soma dos três juntos!\n");

        // Solicita ao usuário o tamanho do primeiro vetor
        System.out.printf("Digite o tamanho do primeiro vetor: ");
        int tam1 = scanner.nextInt();
        int[] v1 = new int[tam1];

        System.out.printf("\nDigite os elementos do primeiro vetor: ");
        for (int i = 0; i < tam1; i++) {
            System.out.printf("Elemento [" + i + "]: ");
            v1[i] = scanner.nextInt();
        }

        // Solicita ao usuário o tamanho do segundo vetor
        System.out.printf("\nDigite o tamanho do segundo vetor: ");
        int tam2 = scanner.nextInt();
        int[] v2 = new int[tam2];

        System.out.printf("\nDigite os elementos do segundo vetor: ");
        for (int i = 0; i < tam2; i++) {
            System.out.printf("Elemento [" + i + "]: ");
            v2[i] = scanner.nextInt();
        }

        // Solicita ao usuário o tamanho do terceiro vetor
        System.out.printf("\nDigite o tamanho do terceiro vetor: ");
        int tam3 = scanner.nextInt();
        int[] v3 = new int[tam3];

        System.out.printf("\nDigite os elementos do terceiro vetor: ");
        for (int i = 0; i < tam3; i++) {
            System.out.printf("Elemento [" + i + "]: ");
            v3[i] = scanner.nextInt();
        }

        System.out.printf("\n\n\n");

        // Imprime os três vetores, independentemente dos tamanhos
        System.out.printf("\nPrimeiro vetor: [");
        for (int i = 0; i < tam1; i++) {
            System.out.print(v1[i]);
            if (i < tam1 - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]");

        System.out.printf("\nSegundo vetor: [");
        for (int i = 0; i < tam2; i++) {
            System.out.print(v2[i]);
            if (i < tam2 - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]");

        System.out.printf("\nTerceiro vetor: [");
        for (int i = 0; i < tam3; i++) {
            System.out.print(v3[i]);
            if (i < tam3 - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]");

        // Verifica se os tamanhos dos vetores são iguais
        boolean tamI = (tam1 == tam2 && tam1 == tam3);

        if (tamI) {
            int tamR = tam1;
            int[] vResultado = new int[tamR];

            for (int i = 0; i < tamR; i++) {
                vResultado[i] = v1[i] + v2[i] + v3[i];
            }

            System.out.printf("\nVetor resultado da soma: [");
            for (int i = 0; i < tamR; i++) {
                System.out.print(vResultado[i]);
                if (i < tamR - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]");
        } else {
            System.out.printf("\nOs vetores têm tamanhos diferentes, a soma não pode ser calculada.");
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!");
    }   
}