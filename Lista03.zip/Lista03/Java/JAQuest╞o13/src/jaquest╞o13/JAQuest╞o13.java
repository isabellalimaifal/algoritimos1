package jaquestão13;
import java.util.Scanner;

public class JAQuestão13 {
    
public class CadastroAlunos {
    public static final int maxA = 100;

    static class Aluno {
        String nome;
        double[] notas = new double[4];
        double media;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\n\nEste programa lê o nome de n alunos de uma escola e suas respectivas 04 notas. O programa localiza o aluno, suas notas, sua média e determina se foi aprovado (com média igual ou superior ao valor 70,00) ou se foi reprovado!");
        System.out.printf("\nQuantos alunos deseja cadastrar? ");
        int numAlunos = scanner.nextInt();
        scanner.nextLine(); // Limpar o caractere de nova linha do buffer

        Aluno[] alunos = new Aluno[maxA];

        for (int i = 0; i < numAlunos; ++i) {
            Aluno aluno = new Aluno();
            System.out.printf("\nInforme o nome do aluno " + (i + 1) + ": ");
            aluno.nome = scanner.nextLine();

            System.out.printf("\nInforme as 4 notas do aluno (separadas por espaço): ");
            String[] notasStr = scanner.nextLine().split(" ");
            for (int j = 0; j < 4; ++j) {
                aluno.notas[j] = Double.parseDouble(notasStr[j]);
            }

            alunos[i] = aluno;
        }

        System.out.printf("\n\n\n");
        System.out.printf("Alunos cadastrados e suas médias:");

        for (int i = 0; i < numAlunos; ++i) {
            double somaNotas = 0;
            for (int j = 0; j < 4; ++j) {
                somaNotas += alunos[i].notas[j];
            }
            alunos[i].media = somaNotas / 4;

            System.out.printf("\nAluno: " + alunos[i].nome);
            System.out.printf("Notas: ");
            for (int j = 0; j < 4; ++j) {
                System.out.print(String.format("%.2f ", alunos[i].notas[j]));
            }
            System.out.printf("\nMédia: " + String.format("%.2f", alunos[i].media));

            if (alunos[i].media >= 70.0) {
                System.out.printf("\nSituação: Aprovado");
            } else {
                System.out.printf("Situação: Reprovado");
            }
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!");
        }
    }
}