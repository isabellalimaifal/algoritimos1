package jaquestão36;
import java.util.Scanner;

public class JAQuestão36 {
public class MatrizTridimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nEste programa carrega uma matriz A do tipo m x n x p, em que m, n e p são números inteiros não negativos!");
        System.out.printf("Digite o valor de m (linhas): ");
        int m = scanner.nextInt();
        System.out.printf("Digite o valor de n (colunas): ");
        int n = scanner.nextInt();
        System.out.printf("Digite o valor de p (profundidade): ");
        int p = scanner.nextInt();
        int[][][] matriz = new int[m][n][p];
        System.out.printf("\nDigite os elementos da matriz " + m + "x" + n + "x" + p + ":");

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < p; k++) {
                    System.out.printf("\nMatriz[" + i + "][" + j + "][" + k + "]: ");
                    matriz[i][j][k] = scanner.nextInt();
                }
            }
        }
        System.out.printf("\nMatriz carregada:");
        imprimirMatriz(matriz);

        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }
    public static void imprimirMatriz(int[][][] matriz) {
        System.out.printf("[ ");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                for (int k = 0; k < matriz[0][0].length; k++) {
                    System.out.printf(matriz[i][j][k] + " ");
                }
            }
        }
        System.out.printf("]");
        }
    }
}