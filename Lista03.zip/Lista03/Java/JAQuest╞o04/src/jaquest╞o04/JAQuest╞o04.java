package jaquestão04;
import java.util.Scanner;

public class JAQuestão04 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanhoA, tamanhoB, tamanhoC;
        System.out.printf("\nEste programa determina o resultado de (3.A + 4.B) – C, para A, B e C vetores , caso seja possível, determinar o resultado final, o programa imprime cada vetor ordenado de maneira crescente!\n\n");

        // Solicita o tamanho do vetor A
        System.out.printf("\nDigite o tamanho do vetor A: ");
        tamanhoA = scanner.nextInt();

        // Solicita o tamanho do vetor B
        System.out.printf("\nDigite o tamanho do vetor B: ");
        tamanhoB = scanner.nextInt();

        // Solicita o tamanho do vetor C
        System.out.printf("\nDigite o tamanho do vetor C: ");
        tamanhoC = scanner.nextInt();

        // Declare os vetores A, B e C com os tamanhos especificados
        int[] A = new int[tamanhoA];
        int[] B = new int[tamanhoB];
        int[] C = new int[tamanhoC];

        // Solicita os elementos do vetor A
        System.out.printf("\nDigite os elementos do vetor A:\n");
        for (int i = 0; i < tamanhoA; i++) {
            System.out.printf("Elemento [%d]: ", i);
            A[i] = scanner.nextInt();
        }

        // Solicita os elementos do vetor B
        System.out.printf("\nDigite os elementos do vetor B:\n");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("Elemento [%d]: ", i);
            B[i] = scanner.nextInt();
        }

        // Solicita os elementos do vetor C
        System.out.printf("\nDigite os elementos do vetor C:\n");
        for (int i = 0; i < tamanhoC; i++) {
            System.out.printf("Elemento [%d]: ", i);
            C[i] = scanner.nextInt();
        }

        System.out.printf("\n\n\n");
        clearConsole();

        // Imprime os vetores A, B e C
        System.out.printf("\nVetor A: [");
        for (int i = 0; i < tamanhoA; i++) {
            System.out.printf("%d", A[i]);
            if (i < tamanhoA - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        System.out.printf("\nVetor B: [");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("%d", B[i]);
            if (i < tamanhoB - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        System.out.printf("\nVetor C: [");
        for (int i = 0; i < tamanhoC; i++) {
            System.out.printf("%d", C[i]);
            if (i < tamanhoC - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        // Verifica se os tamanhos dos vetores são compatíveis para calcular a expressão
        if (tamanhoA == tamanhoB && tamanhoB == tamanhoC) {
            // Calcula o resultado da expressão para cada elemento
            int[] resultado = new int[tamanhoA];
            for (int i = 0; i < tamanhoA; i++) {
                resultado[i] = (3 * A[i] + 4 * B[i]) - C[i];
            }

            // Imprime o vetor de resultados
            System.out.printf("\nVetor D: [");
            for (int i = 0; i < tamanhoA; i++) {
                System.out.printf("%d", resultado[i]);
                if (i < tamanhoA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");

            // Ordena o vetor de resultados em ordem crescente
            ordenarVetor(resultado, tamanhoA);

            // Imprime o vetor de resultados ordenado
            System.out.printf("\nVetor D Ordenado: [");
            for (int i = 0; i < tamanhoA; i++) {
                System.out.printf("%d", resultado[i]);
                if (i < tamanhoA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        } else {
            System.out.printf("\nOs tamanhos dos vetores A, B e C não são compatíveis para calcular a expressão.\n");
        }
        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }

    // Função para ordenar um vetor em ordem crescente
    private static void ordenarVetor(int vetor[], int tamanho) {
        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - i - 1; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    // Troca os elementos se estiverem fora de ordem
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                }
            }
        }
    }

    // Função para limpar o console
    private static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }
}