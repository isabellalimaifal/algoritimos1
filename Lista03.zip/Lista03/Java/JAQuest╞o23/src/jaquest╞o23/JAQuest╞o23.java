package jaquestão23;
import java.util.Scanner;

public class JAQuestão23 {
public class MultiplicaMatrizVetor {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nEste programa multiplica um vetor inteiro por uma matriz inteira (caso seja possível), imprime seus elementos e a soma dos elementos da diagonal principal (caso possível)!\n");
        System.out.printf("Informe o número de linhas da matriz: ");
        int m = scanner.nextInt();
        System.out.printf("Informe o número de colunas da matriz: ");
        int n = scanner.nextInt();
        System.out.printf("Informe o tamanho do vetor: ");
        int vetorLado = scanner.nextInt();
        if (n != vetorLado) {
            System.out.printf("\nA multiplicação não é possível. O número de colunas da matriz deve ser igual ao tamanho do vetor.\n");
            return;
        }
        int[][] matriz = new int[m][n];
        int[] vetor = new int[vetorLado];
        System.out.printf("\nDigite os elementos da matriz: ");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("A[" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }
        System.out.printf("\nDigite os elementos do vetor: ");
        for (int i = 0; i < vetorLado; i++) {
            System.out.printf("V[" + i + "]: ");
            vetor[i] = scanner.nextInt();
        }
        int[] resultado = new int[m];
        int somaDiagonal = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                resultado[i] += matriz[i][j] * vetor[j];
                if (i == j) {
                    somaDiagonal += matriz[i][j];
                }
            }
        }
        System.out.printf("\nVetor informado pelo usuário: " + arrayToString(vetor));
        System.out.printf("\nElementos da matriz informada pelo usuário:");
        printMatrix(matriz);
        System.out.printf("\nResultado da multiplicação: " + arrayToString(resultado));
        System.out.printf("\nSoma dos elementos da diagonal principal: " + somaDiagonal);
        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }
    public static String arrayToString(int[] arr) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i]);
            if (i < arr.length - 1) {
                sb.append(" ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.printf("A[" + i + "][" + j + "]: [" + matrix[i][j] + "]");
                }
            }
        }
    }
}