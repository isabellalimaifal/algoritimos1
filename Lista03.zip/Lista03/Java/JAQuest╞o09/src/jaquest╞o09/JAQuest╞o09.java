package jaquestão09;
import java.util.Scanner;

public class JAQuestão09 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int maxD = 100; // Tamanho máximo das matrizes
        clearConsole();
        System.out.printf("\nEste programa permite realizar a operação em matrizes de números inteiros (A + B) - C, para quaisquer matrizes A, B e C, caso a operação seja possível. Além disso, o programa determina a soma total dos elementos da matriz resultado da operação e imprime todas as matrizes envolvidas!\n");

        // Solicita o tamanho da matriz A
        System.out.printf("\nDigite o número de linhas da matriz A: ");
        int linhasA = scanner.nextInt();
        System.out.printf("\nDigite o número de colunas da matriz A: ");
        int colunasA = scanner.nextInt();

        // Solicita o tamanho da matriz B
        System.out.printf("\nDigite o número de linhas da matriz B: ");
        int linhasB = scanner.nextInt();
        System.out.printf("nDigite o número de colunas da matriz B: ");
        int colunasB = scanner.nextInt();

        // Solicita o tamanho da matriz C
        System.out.printf("nDigite o número de linhas da matriz C: ");
        int linhasC = scanner.nextInt();
        System.out.printf("nDigite o número de colunas da matriz C: ");
        int colunasC = scanner.nextInt();

        // Verifica se as matrizes podem ser somadas e subtraídas
        if (linhasA != linhasB || colunasA != colunasB || linhasA != linhasC || colunasA != colunasC) {
            System.out.printf("\nAs matrizes A, B e C não têm dimensões compatíveis para realizar a operação.\n");
            return;
        }

        // Declara as matrizes A, B, C e a matriz resultante R
        int[][] matrizA = new int[maxD][maxD];
        int[][] matrizB = new int[maxD][maxD];
        int[][] matrizC = new int[maxD][maxD];
        int[][] matrizR = new int[maxD][maxD];

        // Solicita os elementos da matriz A
        System.out.printf("\nDigite os elementos da matriz A (" + linhasA + " x " + colunasA + "):\n");
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                System.out.printf("\nElemento [" + i + "][" + j + "]: ");
                matrizA[i][j] = scanner.nextInt();
            }
        }

        // Solicita os elementos da matriz B
        System.out.printf("\nDigite os elementos da matriz B (" + linhasB + " x " + colunasB + "):\n");
        for (int i = 0; i < linhasB; i++) {
            for (int j = 0; j < colunasB; j++) {
                System.out.printf("\nElemento [" + i + "][" + j + "]: ");
                matrizB[i][j] = scanner.nextInt();
            }
        }

        // Solicita os elementos da matriz C
        System.out.printf("\nDigite os elementos da matriz C (" + linhasC + " x " + colunasC + "):\n");
        for (int i = 0; i < linhasC; i++) {
            for (int j = 0; j < colunasC; j++) {
                System.out.printf("\nElemento [" + i + "][" + j + "]: ");
                matrizC[i][j] = scanner.nextInt();
            }
        }

        // Realiza a operação (A + B) - C e armazena o resultado em R
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                matrizR[i][j] = (matrizA[i][j] + matrizB[i][j]) - matrizC[i][j];
            }
        }

        // Calcula a soma total dos elementos da matriz resultante
        int somaTotal = 0;
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                somaTotal += matrizR[i][j];
            }
        }

        System.out.printf("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime as matrizes A, B, C e a matriz resultante R
        System.out.printf("\nMatriz A:");
        for (int i = 0; i < linhasA; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasA; j++) {
                System.out.print(matrizA[i][j]);
                if (j < colunasA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nMatriz B:");
        for (int i = 0; i < linhasB; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasB; j++) {
                System.out.print(matrizB[i][j]);
                if (j < colunasB - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nMatriz C:");
        for (int i = 0; i < linhasC; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasC; j++) {
                System.out.print(matrizC[i][j]);
                if (j < colunasC - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }

        System.out.printf("\nMatriz Resultante R:");
        for (int i = 0; i < linhasA; i++) {
            System.out.printf("[");
            for (int j = 0; j < colunasA; j++) {
                System.out.print(matrizR[i][j]);
                if (j < colunasA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        }
        System.out.printf("\nSoma total dos elementos da matriz resultante: " + somaTotal + "\n");
        System.out.printf("\n\nObrigado por utilizar nosso programa!\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.printf("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.printf("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}