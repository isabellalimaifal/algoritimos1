package jaquestão41;
import java.util.Scanner;

public class JAQuestão41 {
public class TranspostaMatriz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nEste programa determina a transposta de uma matriz A qualquer. Após isso, o programa deve verificar se a transposta da matriz é igual à própria matriz!");
        System.out.printf("Informe o número de linhas da matriz: ");
        int m = scanner.nextInt();
        System.out.printf("Informe o número de colunas da matriz: ");
        int n = scanner.nextInt();
        int[][] matriz = new int[m][n];
        System.out.printf("Informe os elementos da matriz " + m + "x" + n + ":");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("Matriz[" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }
        System.out.printf("\nMatriz informada pelo usuário:");
        imprimirMatriz(matriz);

        int[][] transposta = new int[n][m];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                transposta[j][i] = matriz[i][j];
            }
        }

        boolean igual = true;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (matriz[i][j] != transposta[i][j]) {
                    igual = false;
                    break;
                }
            }
            if (!igual) {
                break;
            }
        }

        if (igual) {
            System.out.printf("\nA matriz é igual à sua transposta.");
        } else {
            System.out.printf("\nA matriz não é igual à sua transposta.");
        }
        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }
    public static void imprimirMatriz(int[][] matriz) {
        System.out.printf("[ ");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.printf(matriz[i][j] + " ");
            }
            System.out.printf("]");
            }
        }
    }
}