package jaquestão02;
import java.util.Scanner;

public class JAQuestão02 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanhoB, tamanhoC;
        System.out.printf("\nEste programa determina os elementos de A!\n\n");

        // Solicita ao usuário o tamanho do vetor B
        System.out.printf("Informe o tamanho do vetor B: ");
        tamanhoB = scanner.nextInt();

        // Declaração e alocação do vetor B
        int[] vetorB = new int[tamanhoB];

        // Leitura dos elementos do vetor B
        System.out.printf("\nInforme os elementos do vetor B: \n");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("Elemento [%d]: ", i);
            vetorB[i] = scanner.nextInt();
        }

        // Solicita ao usuário o tamanho do vetor C
        System.out.printf("\nInforme o tamanho do vetor C: ");
        tamanhoC = scanner.nextInt();

        // Declaração e alocação do vetor C
        int[] vetorC = new int[tamanhoC];

        // Leitura dos elementos do vetor C
        System.out.printf("\nInforme os elementos do vetor C: \n");
        for (int i = 0; i < tamanhoC; i++) {
            System.out.printf("Elemento [%d]: ", i);
            vetorC[i] = scanner.nextInt();
        }

        // Vetor A terá o tamanho do maior entre B e C
        int tamanhoA = Math.max(tamanhoB, tamanhoC);

        // Declaração e alocação do vetor A
        int[] vetorA = new int[tamanhoA];

        // Verifica se os tamanhos de B e C são iguais
        boolean tamanhosIguais = tamanhoB == tamanhoC;

        if (tamanhosIguais) {
            // Calcula o vetor A se os tamanhos de B e C forem iguais
            for (int i = 0; i < tamanhoA; i++) {
                vetorA[i] = vetorC[i] - vetorB[i];
            }
        }

        System.out.printf("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime os três vetores
        System.out.printf("\nVetor B: [");
        for (int i = 0; i < tamanhoB; i++) {
            System.out.printf("%d", vetorB[i]);
            if (i < tamanhoB - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        System.out.printf("\nVetor C: [");
        for (int i = 0; i < tamanhoC; i++) {
            System.out.printf("%d", vetorC[i]);
            if (i < tamanhoC - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        if (tamanhosIguais) {
            System.out.printf("\nVetor A: [");
            for (int i = 0; i < tamanhoA; i++) {
                System.out.printf("%d", vetorA[i]);
                if (i < tamanhoA - 1) {
                    System.out.printf("  ");
                }
            }
            System.out.printf("]\n");
        } else {
            System.out.printf("\n\nNão é possível calcular a soma dos vetores devido a tamanhos diferentes.\n");
        }

        // Não é necessário liberar a memória alocada em Java, pois o gerenciamento de memória é automático.
        System.out.printf("\n\nObrigado por utilizar nosso programa!\n\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    private static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    private static void pressAnyKeyToContinue() {
        System.out.printf("Pressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}