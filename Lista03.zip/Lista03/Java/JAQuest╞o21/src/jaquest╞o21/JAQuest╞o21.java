package jaquestão21;
import java.util.Scanner;
public class JAQuestão21 {

public class JogoDaVelha {
    private static char[][] tabuleiro = new char[3][3];
    private static char jogadorAtual = 'X';
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\nBem-vindo ao Jogo da Velha!");
        inicializarTabuleiro();
        
        while (true) {
            imprimirTabuleiro();
            System.out.printf("\nJogador " + jogadorAtual + ", digite a linha (1-3) e coluna (1-3) da sua jogada (ex: 2 1): ");
            int linha = scanner.nextInt() - 1;
            int coluna = scanner.nextInt() - 1;

            if (linha < 0 || linha > 2 || coluna < 0 || coluna > 2 || tabuleiro[linha][coluna] != ' ') {
                System.out.printf("\nJogada inválida. Tente novamente.\n");
                continue;
            }

            tabuleiro[linha][coluna] = jogadorAtual;

            if (verificarVitoria()) {
                imprimirTabuleiro();
                System.out.printf("\nJogador " + jogadorAtual + " venceu! Parabéns!");
                break;
            }

            if (verificarEmpate()) {
                imprimirTabuleiro();
                System.out.printf("\nO jogo empatou. Empate!");
                break;
            }

            jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
        }

        System.out.printf("\nObrigado por utilizar nosso programa!\n");
    }

    private static void inicializarTabuleiro() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tabuleiro[i][j] = ' ';
            }
        }
    }

    private static void imprimirTabuleiro() {
        System.out.printf("\n  1 2 3");
        for (int i = 0; i < 3; i++) {
            System.out.printf(i + 1 + " ");
            for (int j = 0; j < 3; j++) {
                System.out.printf(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }
    }

    private static boolean verificarVitoria() {
        for (int i = 0; i < 3; i++) {
            if (tabuleiro[i][0] == jogadorAtual && tabuleiro[i][1] == jogadorAtual && tabuleiro[i][2] == jogadorAtual)
                return true;
            if (tabuleiro[0][i] == jogadorAtual && tabuleiro[1][i] == jogadorAtual && tabuleiro[2][i] == jogadorAtual)
                return true;
        }

        if (tabuleiro[0][0] == jogadorAtual && tabuleiro[1][1] == jogadorAtual && tabuleiro[2][2] == jogadorAtual)
            return true;
        if (tabuleiro[0][2] == jogadorAtual && tabuleiro[1][1] == jogadorAtual && tabuleiro[2][0] == jogadorAtual)
            return true;

        return false;
    }

    private static boolean verificarEmpate() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tabuleiro[i][j] != 'X' && tabuleiro[i][j] != 'O') {
                    return false;
                }
            }
        }
        return true;
        }
    }
}   