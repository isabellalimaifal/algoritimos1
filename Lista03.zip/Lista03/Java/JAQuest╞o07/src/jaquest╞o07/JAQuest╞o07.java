package jaquestão07;
import java.util.Scanner;

public class JAQuestão07 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int maxV = 10; // Número máximo de vetores
        final int maxE = 100; // Número máximo de elementos em cada vetor
        int[][] vetores = new int[maxV][maxE];
        int numVetores = 0;
        int[] tamanhoVetor = new int[maxV];

        System.out.printf("\nEste programa oferece uma funcionalidade flexível de soma de vetores, permitindo somar quantas coleções de números desejar, desde que seja possível realizar a operação. O programa apresenta um menu de opções!\n");

        while (true) {
            int opcao;
            System.out.printf("\nMenu de Opções:\n");
            System.out.printf("\n1. Adicionar um vetor\n");
            System.out.printf("\n2. Somar vetores\n");
            System.out.printf("\n3. Sair\n");
            System.out.printf("\nEscolha uma opção: ");
            opcao = scanner.nextInt();

            if (opcao == 1) {
                if (numVetores < maxV) {
                    int tamanho;
                    System.out.printf("\nDigite o tamanho do vetor: ");
                    tamanho = scanner.nextInt();

                    if (tamanho <= maxE) {
                        System.out.printf("\nDigite os elementos do vetor:\n");
                        for (int i = 0; i < tamanho; i++) {
                            System.out.printf("Elemento [" + numVetores + "][" + i + "]: ");
                            vetores[numVetores][i] = scanner.nextInt();
                        }

                        tamanhoVetor[numVetores] = tamanho;
                        numVetores++;
                    } else {
                        System.out.printf("\nO tamanho do vetor excede o limite permitido.\n");
                    }
                } else {
                    System.out.printf("\nNúmero máximo de vetores atingido.\n");
                }
            } else if (opcao == 2) {
                if (numVetores < 2) {
                    System.out.printf("\nÉ necessário ter pelo menos dois vetores para realizar a soma.\n");
                } else {
                    // Verifica se os tamanhos dos vetores são compatíveis
                    int tamanho = tamanhoVetor[0];
                    boolean tamanhosCompativeis = true;
                    for (int i = 1; i < numVetores; i++) {
                        if (tamanhoVetor[i] != tamanho) {
                            tamanhosCompativeis = false;
                            break;
                        }
                    }

                    if (tamanhosCompativeis) {
                        int[] resultado = new int[maxE];
                        for (int i = 0; i < tamanho; i++) {
                            for (int j = 0; j < numVetores; j++) {
                                resultado[i] += vetores[j][i];
                            }
                        }

                        System.out.printf("\n\n\n");
                        pressAnyKeyToContinue();
                        clearConsole();

                        // Imprime o resultado da soma
                        System.out.printf("\nResultado da soma: [");
                        for (int i = 0; i < tamanho; i++) {
                            System.out.print(resultado[i]);
                            if (i < tamanho - 1) {
                                System.out.printf("  ");
                            }
                        }
                        System.out.printf("]\n");

                        // Imprime os elementos dos vetores
                        System.out.printf("\nElementos dos vetores:");
                        for (int i = 0; i < numVetores; i++) {
                            System.out.printf("\nVetor " + (i + 1) + ": [");
                            for (int j = 0; j < tamanho; j++) {
                                System.out.print(vetores[i][j]);
                                if (j < tamanho - 1) {
                                    System.out.printf("  ");
                                }
                            }
                            System.out.printf("]");
                        }
                    } else {
                        System.out.printf("\nOs tamanhos dos vetores não são compatíveis para realizar a soma.\n");
                    }
                }
            } else if (opcao == 3) {
                break;
            } else {
                System.out.printf("\nOpção inválida. Tente novamente.\n");
            }
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!\n");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.printf("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.printf("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}