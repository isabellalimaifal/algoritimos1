package jaquestão14;
import java.util.Scanner;

public class JAQuestão14 {
    
    public class OrdenacaoESoma {
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("\n\nEste programa lê um vetor inteiro de tamanho n, e ordena-o de maneira crescente, soma seus valores e determina se o resultado da soma é um número par ou um número ímpar!");
        System.out.printf("\nInforme o tamanho do vetor: ");
        int n = scanner.nextInt();
        int[] vetor = new int[n];
        int[] vetorOriginal = new int[n];

        System.out.printf("\nInforme os elementos do vetor: ");
        for (int i = 0; i < n; i++) {
            System.out.printf("Vetor [" + i + "]: ");
            vetor[i] = scanner.nextInt();
            vetorOriginal[i] = vetor[i];
        }

        bubbleSort(vetor);

        int soma = 0;
        for (int i = 0; i < n; i++) {
            soma += vetor[i];
        }

        System.out.printf("\n\n\n");
        scanner.nextLine(); // Limpar o caractere de nova linha do buffer

        System.out.printf("\nVetor ordenado em ordem crescente: [ ");
        for (int i = 0; i < n; i++) {
            System.out.printf(vetor[i] + " ");
        }
        System.out.printf("]");

        System.out.printf("\nSoma dos valores: " + soma);

        if (soma % 2 == 0) {
            System.out.printf("\nA soma dos valores é um número par.");
        } else {
            System.out.printf("\nA soma dos valores é um número ímpar.");
        }

        System.out.printf("\nVetor original informado: [ ");
        for (int i = 0; i < n; i++) {
            System.out.printf(vetorOriginal[i] + " ");
        }
        System.out.printf("]");

        System.out.printf("\n\nObrigado por utilizar nosso programa!");
        }   
    }
}