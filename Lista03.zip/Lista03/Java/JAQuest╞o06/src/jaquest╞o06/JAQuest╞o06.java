package jaquestão06;
import java.util.Scanner;

public class JAQuestão06 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanho;
        System.out.printf("\nEste programa permite ao usuário inserir um vetor de números inteiros e, em seguida, busca por um número específico dentro desse vetor!\n");

        // Solicita o tamanho do vetor
        System.out.printf("Digite o tamanho do vetor: ");
        tamanho = scanner.nextInt();

        // Declare o vetor com o tamanho especificado
        int[] vetor = new int[tamanho];

        // Solicita os elementos do vetor com as posições
        System.out.printf("\nDigite os elementos do vetor:\n");
        for (int i = 0; i < tamanho; i++) {
            System.out.printf("Elemento [" + i + "] ");
            vetor[i] = scanner.nextInt();
        }

        System.out.printf("\n\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime o vetor na ordem original
        System.out.printf("\nVetor Original: [");
        for (int i = 0; i < tamanho; i++) {
            System.out.print(vetor[i]);
            if (i < tamanho - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        // Busca um número na estrutura
        int numero;
        System.out.printf("Digite o número que deseja buscar: ");
        numero = scanner.nextInt();

        System.out.printf("\n\n");
        pressAnyKeyToContinue();
        clearConsole();

        // Imprime o vetor na ordem original
        System.out.printf("\nVetor Original: [");
        for (int i = 0; i < tamanho; i++) {
            System.out.print(vetor[i]);
            if (i < tamanho - 1) {
                System.out.printf("  ");
            }
        }
        System.out.printf("]\n");

        // Busca e imprime a posição de cada repetição do número
        int encontrado = 0;
        System.out.printf("Posições do número " + numero + ": [");
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i] == numero) {
                if (encontrado > 0) {
                    System.out.printf("  ");
                }
                System.out.print(i);
                encontrado++;
            }
        }
        System.out.printf("]");

        if (encontrado == 0) {
            System.out.printf("\nO número " + numero + " não foi encontrado no vetor.");
        }
        System.out.printf("\nObrigado por utilizar nosso programa!");
        pressAnyKeyToContinue();
    }

    // Função para limpar o console
    static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Ignorar erros ao limpar o console
        }
    }

    // Função para aguardar o pressionamento de qualquer tecla
    static void pressAnyKeyToContinue() {
        System.out.print("\nPressione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            // Ignorar erros ao ler a entrada do teclado
        }
    }
}