package jaquestão11;
import java.util.Scanner;

public class JAQuestão11 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxL = 100;
        int maxC = 100;
        System.out.printf("\n\nEste programa realiza operações com matrizes, incluindo multiplicação, soma e multiplicação por um número real. Também calcula o traço da matriz resultante, se ela for quadrada, utilizando números reais!");

        int linhasA, colunasA, linhasB, colunasB, linhasC, colunasC;
        double[][] matrizA = new double[maxL][maxC];
        double[][] matrizB = new double[maxL][maxC];
        double[][] matrizC = new double[maxL][maxC];
        double multiplicador;

        System.out.printf("\nInforme o número de linhas da matriz A: ");
        linhasA = scanner.nextInt();
        System.out.printf("\nInforme o número de colunas da matriz A: ");
        colunasA = scanner.nextInt();

        System.out.printf("\nInforme o número de linhas da matriz B: ");
        linhasB = scanner.nextInt();
        System.out.printf("\nInforme o número de colunas da matriz B: ");
        colunasB = scanner.nextInt();

        System.out.printf("\nInforme o número de linhas da matriz C: ");
        linhasC = scanner.nextInt();
        System.out.printf("\nInforme o número de colunas da matriz C: ");
        colunasC = scanner.nextInt();

        System.out.printf("\n\n\n");
        scanner.nextLine(); // Limpar o caractere de nova linha do buffer

        System.out.printf("Digite os elementos da matriz A (posição A[i][j]):");
        for (int i = 0; i < linhasA; ++i) {
            for (int j = 0; j < colunasA; ++j) {
                System.out.printf("A[" + i + "][" + j + "]: ");
                matrizA[i][j] = scanner.nextDouble();
            }
        }

        System.out.printf("\nDigite os elementos da matriz B (posição B[i][j]):");
        for (int i = 0; i < linhasB; ++i) {
            for (int j = 0; j < colunasB; ++j) {
                System.out.printf("B[" + i + "][" + j + "]: ");
                matrizB[i][j] = scanner.nextDouble();
            }
        }

        System.out.printf("\nDigite os elementos da matriz C (posição C[i][j]):");
        for (int i = 0; i < linhasC; ++i) {
            for (int j = 0; j < colunasC; ++j) {
                System.out.printf("C[" + i + "][" + j + "]: ");
                matrizC[i][j] = scanner.nextDouble();
            }
        }

        System.out.printf("\n\n\n");
        scanner.nextLine(); // Limpar o caractere de nova linha do buffer

        System.out.printf("Informe o valor do multiplicador: ");
        multiplicador = scanner.nextDouble();

        double[][] AB = new double[maxL][maxC];
        if (colunasA == linhasB) {
            multiplicarMatrizes(matrizA, linhasA, colunasA, matrizB, linhasB, colunasB, AB);
            linhasC = linhasA;
            colunasC = colunasB;
        } else {
            System.out.printf("\nA multiplicação de A e B não é possível.");
            return;
        }

        double[][] resultado = new double[maxL][maxC];
        if (linhasC == linhasA && colunasC == colunasA) {
            somarMatrizes(matrizA, linhasA, colunasA, matrizB, linhasB, colunasB, resultado);
        } else {
            System.out.printf("\nA soma de A, B e C não é possível.");
            return;
        }

        for (int i = 0; i < linhasC; ++i) {
            for (int j = 0; j < colunasC; ++j) {
                resultado[i][j] *= multiplicador;
            }
        }

        double traco = 0.0;
        if (linhasC == colunasC) {
            for (int i = 0; i < linhasC; ++i) {
                traco += resultado[i][i];
            }
        }

        System.out.printf("\nMatriz Resultante:");
        for (int i = 0; i < linhasC; ++i) {
            System.out.print("[ ");
            for (int j = 0; j < colunasC; ++j) {
                System.out.printf(resultado[i][j] + " ");
            }
            System.out.printf("]");
        }

        if (linhasC == colunasC) {
            System.out.printf("\nTraço da Matriz Resultante: [" + traco + "]");
        } else {
            System.out.printf("\nO cálculo do traço não é possível.");
        }

        System.out.printf("\n\nObrigado por utilizar nosso programa!");
    }

    public static void multiplicarMatrizes(double[][] A, int linhasA, int colunasA, double[][] B, int linhasB, int colunasB, double[][] resultado) {
        for (int i = 0; i < linhasA; ++i) {
            for (int j = 0; j < colunasB; ++j) {
                resultado[i][j] = 0.0;
                for (int k = 0; k < colunasA; ++k) {
                    resultado[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }

    public static void somarMatrizes(double[][] A, int linhasA, int colunasA, double[][] B, int linhasB, int colunasB, double[][] resultado) {
        if (linhasA == linhasB && colunasA == colunasB) {
            for (int i = 0; i < linhasA; ++i) {
                for (int j = 0; j < colunasA; ++j) {
                    resultado[i][j] = A[i][j] + B[i][j];
                }
            }
        }
    }
}