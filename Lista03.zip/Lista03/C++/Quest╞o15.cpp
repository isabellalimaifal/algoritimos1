#include <stdio.h>
#include <locale.h>
#include <stdlib.h>


int main() {
    int rodadas;
    printf("Esse programa possibilita o usurio a jogue xadres: ");
    printf("\nDigite o n�mero de rodadas: ");
    scanf("%d", &rodadas);

    int equipes[5][rodadas];
    int idades[5];
    int pontuacoes[5] = {0};

    for (int i = 0; i < 5; i++) {
        printf("\nDigite a idade do competidor %d: ", i + 1);
        scanf("%d", &idades[i]);
    }

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < rodadas; j++) {
            printf("\nDigite a pontua��o da equipe %d na rodada %d (0, 1 ou 3): ", i + 1, j + 1);
            scanf("%d", &equipes[i][j]);

      
            if (equipes[i][j] != 0 && equipes[i][j] != 1 && equipes[i][j] != 3) {
                printf("\nPontua��o inv�lida! Use 0, 1 ou 3.\n");
                j--;
            }
        }
    }

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < rodadas; j++) {
            pontuacoes[i] += equipes[i][j];
        }
    }

    int equipeVencedora = 0;

    for (int i = 1; i < 5; i++) {
        if (pontuacoes[i] > pontuacoes[equipeVencedora]) {
            equipeVencedora = i;
        }
    }

    printf("\nClassifica��o Final:\n");
    for (int i = 0; i < 5; i++) {
        printf("Equipe %d - Pontua��o Total: %d", i + 1, pontuacoes[i]);
        if (i == equipeVencedora) {
            printf(" (\nEquipe Vencedora)\n");
        } else {
            printf("\n");
        }
    }

    return 0;
}
