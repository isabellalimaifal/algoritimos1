#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	int i, j, somaDiagonal = 0, somaAbaixodaDiagonal = 0;


	printf ("\n\nEste programa carrega e imprime uma matriz A 10x10 � determina a soma dos elementos abeixo da diagonal principal da matriz incluindo os elementos da pr�pria diagonal!\n\n");
	
	printf ("\n\nInforme os elementos da matriz A!");
	int A[10][10];
	
	for (i = 0; i < 10; i++) { 
		for (j = 0; j < 10; j++) { 
			printf ("\n\nInforme o elemento na posi��o A[%d][%d]: ", i, j);
			scanf ("%d", &A[i][j]);
		}
	}
	printf ("\n\n\n");
	system ("Pause");
	system ("cls");
	
	printf("\n\n\nA = \n");
    for (i = 0; i < 10; i++) {
        printf("\n");
        for (j = 0; j < 10; j++) {
            printf(" %d ", A[i][j]);
        }
    }
    
    printf ("\n\n\n");

	for (i = 0; i < 10; i++) {
    	for (j = 0; j < 10; j++) { 
        	if (i==j) {
				somaDiagonal = somaDiagonal + A[i][j];
        	}else if (i > j) {
				somaAbaixodaDiagonal = somaAbaixodaDiagonal + A[i][j];

     	}	}
	}       

	printf ("\n\nA soma dos elementos abaixo da diagonal principal � de: %d ", somaAbaixodaDiagonal);
	printf ("\n\nA soma dos elementos da diagonal principal � de: %d ", somaDiagonal);
 

	printf ("\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
