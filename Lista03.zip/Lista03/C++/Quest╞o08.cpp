#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxD = 100; // Tamanho m�ximo das matrizes

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int linhasA, colunasA, linhasB, colunasB;
    printf("\nEste programa permite a soma de duas matrizes (A e B) e, caso seja poss�vel realizar a opera��o, determina a matriz transposta da matriz resultante, bem como a soma de seus elementos!\n");
    
    // Solicita o tamanho da matriz A
    printf("\nDigite o n�mero de linhas da matriz A: ");
    scanf("%d", &linhasA);
    printf("\nDigite o n�mero de colunas da matriz A: ");
    scanf("%d", &colunasA);

    // Solicita o tamanho da matriz B
    printf("\nDigite o n�mero de linhas da matriz B: ");
    scanf("%d", &linhasB);
    printf("\nDigite o n�mero de colunas da matriz B: ");
    scanf("%d", &colunasB);

    // Verifica se as matrizes podem ser somadas
    if (linhasA != linhasB || colunasA != colunasB) {
        printf("\nAs matrizes A e B n�o podem ser somadas devido a tamanhos diferentes.\n");
        return 0;
    }

    // Declara as matrizes A, B e a matriz resultante C
    int matrizA[maxD][maxD];
    int matrizB[maxD][maxD];
    int matrizC[maxD][maxD];
    
	// Solicita os elementos da matriz A
    printf("\nDigite os elementos da matriz A (%d x %d):\n", linhasA, colunasA);
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matrizA[i][j]);
        }
    }

    // Solicita os elementos da matriz B
    printf("\nDigite os elementos da matriz B (%d x %d):\n", linhasB, colunasB);
    for (int i = 0; i < linhasB; i++) {
        for (int j = 0; j < colunasB; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matrizB[i][j]);
        }
    }

    // Realiza a soma das matrizes A e B e armazena o resultado em C
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            matrizC[i][j] = matrizA[i][j] + matrizB[i][j];
        }
    }

    // Calcula a transposta da matriz resultante
    int matrizTransposta[maxD][maxD];
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            matrizTransposta[j][i] = matrizC[i][j];
        }
    }

    // Calcula a soma dos elementos da matriz resultante
    int somaElementos = 0;
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            somaElementos += matrizC[i][j];
        }
    }

	printf("\n\n\n");
	system ("Pause");
	system("cls");

    // Imprime as matrizes A, B, C e a transposta da matriz C
    printf("\nMatriz A:\n");
    for (int i = 0; i < linhasA; i++) {
        printf("[");
        for (int j = 0; j < colunasA; j++) {
            printf("%d", matrizA[i][j]);
            if (j < colunasA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nMatriz B:\n");
    for (int i = 0; i < linhasB; i++) {
        printf("[");
        for (int j = 0; j < colunasB; j++) {
            printf("%d", matrizB[i][j]);
            if (j < colunasB - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nMatriz Resultante C:\n");
    for (int i = 0; i < linhasA; i++) {
        printf("[");
        for (int j = 0; j < colunasA; j++) {
            printf("%d", matrizC[i][j]);
            if (j < colunasA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nTransposta da Matriz C:\n");
    for (int i = 0; i < colunasA; i++) {
        printf("[");
        for (int j = 0; j < linhasA; j++) {
            printf("%d", matrizTransposta[i][j]);
            if (j < linhasA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }
    printf("\nSoma dos elementos da matriz resultante: %d\n", somaElementos);
  	printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
