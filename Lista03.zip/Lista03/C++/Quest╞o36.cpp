#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
	int m, n, p;
	printf("\n\nEste programa carrega uma matriz A do tipo m x n x p, em que m, n e p s�o n�meros inteiros n�o negativos!\n");
    printf("\nDigite o valor de m (linhas): ");
    scanf("%d", &m);

    printf("\nDigite o valor de n (colunas): ");
    scanf("%d", &n);

    printf("\nDigite o valor de p (profundidade): ");
    scanf("%d", &p);

    int matriz[m][n][p];

    printf("\nDigite os elementos da matriz %dx%dx%d:\n", m, n, p);

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                printf("\nMatriz[%d][%d][%d]: ", i, j, k);
                scanf("%d", &matriz[i][j][k]);
            }
        }
    }
	printf("\nMatriz carregada:\n [ ");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                printf("%d ", matriz[i][j][k]); // Imprime os elementos separados por espa�o
            }
        }
    }

    printf("]\n");           
	printf("\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
