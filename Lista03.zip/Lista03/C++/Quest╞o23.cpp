#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int m, n, vetorLado;
    printf("\n\nEste programa multiplica um vetor inteiro por uma matriz inteira (caso seja poss�vel), imprime seus elementos e a soma dos elementos da diagonal principal (caso poss�vel)!\n");
    printf("\nInforme o n�mero de linhas da matriz: ");
    scanf("%d", &m);
    printf("\nInforme o n�mero de colunas da matriz: ");
    scanf("%d", &n);
    printf("\nInforme o tamanho do vetor: ");
    scanf("%d", &vetorLado);

    if (n != vetorLado) {
        printf("\nA multiplica��o n�o � poss�vel. O n�mero de colunas da matriz deve ser igual ao tamanho do vetor.\n");
        return 1;
    }

    int matriz[100][100]; 
    int vetor[100];      

    printf("\nDigite os elementos da matriz: \n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("A[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("\nDigite os elementos do vetor: \n");
    for (int i = 0; i < vetorLado; i++) {
        printf("V[%d]: ", i);
        scanf("%d", &vetor[i]);
    }

    int resultado[100] = {0}; 
    int somaDiagonal = 0;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            resultado[i] += matriz[i][j] * vetor[j];
            if (i == j) {
                somaDiagonal += matriz[i][j];
            }
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    printf("\nVetor informado pelo usu�rio: [");
    for (int i = 0; i < vetorLado; i++) {
        printf("%d", vetor[i]);
        if (i < vetorLado - 1) {
            printf(" ");
        }
    }
    printf("]\n");

    printf("\nElementos da matriz informada pelo usu�rio:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("A[%d][%d]: [%d]\n", i, j, matriz[i][j]);
        }
    }

    printf("\nResultado da multiplica��o: [");
    for (int i = 0; i < m; i++) {
        printf("%d", resultado[i]);
        if (i < m - 1) {
            printf(" ");
        }
    }
    printf("]\n");

    printf("\nSoma dos elementos da diagonal principal: %d\n", somaDiagonal);
    printf("\n\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
