#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

// Fun��o para ordenar um vetor em ordem crescente 
void ordenarVetor(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = 0; j < tamanho - i - 1; j++) {
            if (vetor[j] > vetor[j + 1]) {
                // Troca os elementos se estiverem fora de ordem
                int temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
            }
        }
    }
}

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tamanhoA, tamanhoB, tamanhoC;
    printf("\nEste programa determina o resultado de (3.A + 4.B) � C, para A, B e C vetores , caso poss�vel, determinar o resultado final, o programa imprime cada vetor ordenado de maneira crescente!\n\n");
    
    // Solicita o tamanho do vetor A
    printf("\nDigite o tamanho do vetor A: ");
    scanf("%d", &tamanhoA);
    
    // Solicita o tamanho do vetor B
    printf("\nDigite o tamanho do vetor B: ");
    scanf("%d", &tamanhoB);

    // Solicita o tamanho do vetor C
    printf("\nDigite o tamanho do vetor C: ");
    scanf("%d", &tamanhoC);
    
    // Declare os vetores A, B e C com os tamanhos especificados
    int A[tamanhoA];
    int B[tamanhoB];
    int C[tamanhoC];
    
    // Solicita os elementos do vetor A
    printf("\nDigite os elementos do vetor A:\n");
    for (int i = 0; i < tamanhoA; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &A[i]);
    }
    
    // Solicita os elementos do vetor B
    printf("\nDigite os elementos do vetor B:\n");
    for (int i = 0; i < tamanhoB; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &B[i]);
    }

    // Solicita os elementos do vetor C
    printf("\nDigite os elementos do vetor C:\n");
    for (int i = 0; i < tamanhoC; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &C[i]);
    }
    
    printf("\n\n\n");
	system ("Pause");
	system("cls");
    
    // Imprime os vetores A, B e C
    printf("\nVetor A: [");
    for (int i = 0; i < tamanhoA; i++) {
        printf("%d", A[i]);
        if (i < tamanhoA - 1) {
            printf("  ");
        }
    }
    printf("]\n");
    
    printf("\nVetor B: [");
    for (int i = 0; i < tamanhoB; i++) {
        printf("%d", B[i]);
        if (i < tamanhoB - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    printf("\nVetor C: [");
    for (int i = 0; i < tamanhoC; i++) {
        printf("%d", C[i]);
        if (i < tamanhoC - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    // Verifica se os tamanhos dos vetores s�o compat�veis para calcular a express�o
    if (tamanhoA == tamanhoB && tamanhoB == tamanhoC) {
        // Calcula o resultado da express�o para cada elemento
        int resultado[tamanhoA];
        for (int i = 0; i < tamanhoA; i++) {
            resultado[i] = (3 * A[i] + 4 * B[i]) - C[i];
        }

        // Imprime o vetor de resultados
        printf("\nVetor D: [");
        for (int i = 0; i < tamanhoA; i++) {
            printf("%d", resultado[i]);
            if (i < tamanhoA - 1) {
                printf("  ");
            }
        }
        printf("]\n");	

        // Ordena o vetor de resultados em ordem crescente
        ordenarVetor(resultado, tamanhoA);

        // Imprime o vetor de resultados ordenado
        printf("\nVetor D Ordenado: [");
        for (int i = 0; i < tamanhoA; i++) {
            printf("%d", resultado[i]);
            if (i < tamanhoA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    } else {
        printf("\n\nOs tamanhos dos vetores A, B e C n�o s�o compat�veis para calcular a express�o.\n");
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
