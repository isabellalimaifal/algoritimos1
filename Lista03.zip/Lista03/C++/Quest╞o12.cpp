#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    const int maxPalavras = 100;
    char palavras[maxPalavras][100];
    int n;
    printf("\n\nEste programa l� e armazena n palavras e, depois, ap�s digitar uma palavra qualquer, o programa faz a busca da palavra digitada entre as palavras armazenadas!\n");
    printf("\nInforme o n�mero de palavras a serem inseridas: ");
    scanf("%d", &n);

    // Limpar o buffer de entrada
    while (getchar() != '\n');

    // Ler e armazenar as palavras
    for (int i = 0; i < n; ++i) {
        printf("Informe a palavra #%d: ", i + 1);
        fgets(palavras[i], sizeof(palavras[i]), stdin);

        // Remover o caractere de nova linha, se estiver presente
        size_t len = strlen(palavras[i]);
        if (len > 0 && palavras[i][len - 1] == '\n') {
            palavras[i][len - 1] = '\0';
        }
    }

    // Solicitar a palavra a ser procurada
    char palavraProcurada[100];
    printf("\nInforma a palavra a ser procurada: ");
    scanf("%s", palavraProcurada);

    int ultimaPosicao = -1;  // Inicializar a �ltima posi��o como -1 (indicando que n�o foi encontrada)
    int quantidadeRepeticoes = 0;

    // Procurar a palavra na lista e contar repeti��es
    for (int i = 0; i < n; ++i) {
        if (strcmp(palavras[i], palavraProcurada) == 0) {
            ultimaPosicao = i;
            quantidadeRepeticoes++;
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Verificar se a palavra foi encontrada
    if (ultimaPosicao != -1) {
        printf("\nA palavra '%s' foi encontrada pela �ltima vez na posi��o %d.\n", palavraProcurada, ultimaPosicao + 1);
        printf("\nEla aparece %d vez(es) na lista.\n", quantidadeRepeticoes);
    } else {
        printf("\nA palavra '%s' n�o foi encontrada na lista.\n", palavraProcurada);
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}

