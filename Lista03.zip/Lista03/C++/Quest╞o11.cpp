#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxL = 100;
const int maxC = 100;

void multiplicarMatrizes(double A[][maxC], int linhasA, int colunasA, double B[][maxC], int linhasB, int colunasB, double resultado[][maxC]) {
    for (int i = 0; i < linhasA; ++i) {
        for (int j = 0; j < colunasB; ++j) {
            resultado[i][j] = 0.0;
            for (int k = 0; k < colunasA; ++k) {
                resultado[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void somarMatrizes(double A[][maxC], int linhasA, int colunasA, double B[][maxC], int linhasB, int colunasB, double resultado[][maxC]) {
    if (linhasA == linhasB && colunasA == colunasB) {
        for (int i = 0; i < linhasA; ++i) {
            for (int j = 0; j < colunasA; ++j) {
                resultado[i][j] = A[i][j] + B[i][j];
            }
        }
    }
}

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int linhasA, colunasA, linhasB, colunasB, linhasC, colunasC;
    double matrizA[maxL][maxC], matrizB[maxL][maxC], matrizC[maxL][maxC];
    double multiplicador;

    printf("\n\nEste programa realiza opera��es com matrizes, incluindo multiplica��o, soma e multiplica��o por um n�mero real. Tamb�m calcula o tra�o da matriz resultante, se ela for quadrada, utilizando n�meros reais!");

    // Perguntas para as dimens�es das matrizes A, B e C
    printf("\n\nInforme o n�mero de linhas da matriz A: ");
    scanf("%d", &linhasA);
    printf("\nInforme o n�mero de colunas da matriz A: ");
    scanf("%d", &colunasA);

    printf("\nInforme o n�mero de linhas da matriz B: ");
    scanf("%d", &linhasB);
    printf("\nInforme o n�mero de colunas da matriz B: ");
    scanf("%d", &colunasB);

    printf("\nInforme o n�mero de linhas da matriz C: ");
    scanf("%d", &linhasC);
    printf("\nInforme o n�mero de colunas da matriz C: ");
    scanf("%d", &colunasC);
	
    printf("\n\n\n");
	system ("Pause");
	system("cls");

    printf("\nDigite os elementos da matriz A (posi��o A[i][j]):\n");
    for (int i = 0; i < linhasA; ++i) {
        for (int j = 0; j < colunasA; ++j) {
            printf("A[%d][%d]: ", i, j);
            scanf("%lf", &matrizA[i][j]);
        }
    }

    printf("\n\nDigite os elementos da matriz B (posi��o B[i][j]):\n");
    for (int i = 0; i < linhasB; ++i) {
        for (int j = 0; j < colunasB; ++j) {
            printf("B[%d][%d]: ", i, j);
            scanf("%lf", &matrizB[i][j]);
        }
    }

    printf("\nDigite os elementos da matriz C (posi��o C[i][j]):\n");
    for (int i = 0; i < linhasC; ++i) {
        for (int j = 0; j < colunasC; ++j) {
            printf("C[%d][%d]: ", i, j);
            scanf("%lf", &matrizC[i][j]);
        }
    }
	
    printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    printf("\nInforme o valor do multiplicador: ");
    scanf("%lf", &multiplicador);

    double AB[maxL][maxC];
    if (colunasA == linhasB) {
        multiplicarMatrizes(matrizA, linhasA, colunasA, matrizB, linhasB, colunasB, AB);
        linhasC = linhasA;
        colunasC = colunasB;
    } else {
        printf("\nA multiplica��o de A e B n�o � poss�vel.\n");
        return 1;
    }

    double resultado[maxL][maxC];
    if (linhasC == linhasA && colunasC == colunasA) {
        somarMatrizes(matrizA, linhasA, colunasA, matrizB, linhasB, colunasB, resultado);
    } else {
        printf("\nA soma de A, B e C n�o � poss�vel.\n");
        return 1;
    }

    for (int i = 0; i < linhasC; ++i) {
        for (int j = 0; j < colunasC; ++j) {
            resultado[i][j] *= multiplicador;
        }
    }

    double traco = 0.0;
    if (linhasC == colunasC) {
        for (int i = 0; i < linhasC; ++i) {
            traco += resultado[i][i];
        }
    }

    printf("\nMatriz Resultante:\n");
    for (int i = 0; i < linhasC; ++i) {
        printf("[ ");
        for (int j = 0; j < colunasC; ++j) {
            printf("%g ", resultado[i][j]);
        }
        printf("]\n");
    }

    if (linhasC == colunasC) {
        printf("\nTra�o da Matriz Resultante: [%g]\n", traco);
    } else {
        printf("\nO c�lculo do tra�o n�o � poss�vel.\n");
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}

