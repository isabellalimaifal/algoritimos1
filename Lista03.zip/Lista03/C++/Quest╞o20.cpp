#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(void) {
    system("cls");
    setlocale(LC_ALL, "Portuguese");

    int linhas, colunas;
    char letra;
    int contador = 0;

    printf("\n\nEste programa informa a quantidade de vezes que uma letra � encontrada na matriz.\n");
    printf("\n\nInforme a quantidade de linhas: ");
    scanf("%d", &linhas);

    printf("\nInforme a quantidade de colunas: ");
    scanf("%d", &colunas);

    char matriz[linhas][colunas];

    printf("\nDigite a matriz de caracteres:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            scanf(" %c", &matriz[i][j]);
        }
    }

    printf("\nInforme a letra que dever� ser encontrada: ");
    scanf(" %c", &letra); 

    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (matriz[i][j] == letra) {
                contador++;
            }
        }
    }

    printf("\nA letra '%c' foi encontrada %d vezes na matriz.\n", letra, contador);
    printf("\n\nObrigado por utilizar o nosso programa!\n");

    return 0;
}
