#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(void) {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int i, j, diagonal = 1, superior = 1, inferior = 1;

    printf("\n\nEste programa carrega e imprime uma matriz A 5x5 � imforma de acordo com a matriz que foi digitada se a diagonal dela � triangular inferior ou superior!");
    printf("\n\nInforme os elementos da matriz A!");

    int A[5][5];

    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            printf("\n\nInforme o elemento na posi��o A[%d][%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    printf("\n\n\n");
    system("Pause");
    system("cls");

    printf("\n\n\nA = \n");
    for (i = 0; i < 5; i++) {
        printf("\n");
        for (j = 0; j < 5; j++) {
            printf(" %d ", A[i][j]);
        }
    }

    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            if (i != j && A[i][j] != 0) {
                diagonal = 0;
                if (i < j) {
                    inferior = 0;
                } else if (i > j) {
                    superior = 0;
                }
            }
        }
    }

    if (diagonal) {
        printf("\n\nA matriz � diagonal!\n\n");
    } else if (inferior) {
        printf("\n\nA matriz � triangular inferior!\n\n");
    } else if (superior) {
        printf("\n\nA matriz � triangular superior!\n\n");
    } else {
        printf("\n\nA matriz n�o � diagonal, superior nem triangular inferior!\n\n");
    }

    printf("\n\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
