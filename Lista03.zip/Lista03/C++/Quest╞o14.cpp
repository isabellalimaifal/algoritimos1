#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // Trocar os elementos se estiverem fora de ordem
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int n;
	printf("\n\nEste programa l� um vetor inteiro de tamanho n, e ordena-o de maneira crescente, soma seus valores e determina se o resultado da soma e um n�mero par ou um n�mero �mpar!");
    printf("\n\nInforme o tamanho do vetor: ");
    scanf("%d", &n);

    int vetor[n];

    printf("\n\nInforme os elementos do vetor: \n");
    for (int i = 0; i < n; i++) {
        printf("Vetor [%d]: ", i);
        scanf("%d", &vetor[i]);
    }

    int vetorOriginal[n]; // Armazenar o vetor original

    for (int i = 0; i < n; i++) {
        vetorOriginal[i] = vetor[i];
    }

    // Ordenar o vetor em ordem crescente usando Bubble Sort
    bubbleSort(vetor, n);

    // Calcular a soma dos valores do vetor
    int soma = 0;
    for (int i = 0; i < n; i++) {
        soma += vetor[i];
    }

	printf("\n\n\n");
	system ("Pause");
	system("cls");

    printf("\nVetor ordenado em ordem crescente: [ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", vetor[i]);
    }
    printf("]\n");

    printf("\nSoma dos valores: %d\n", soma);

    if (soma % 2 == 0) {
        printf("\nA soma dos valores e um numero par.\n");
    } else {
        printf("\nA soma dos valores e um numero impar.\n");
    }

    printf("\nVetor original informado: [ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", vetorOriginal[i]);
    }
    printf("]\n");
    
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
