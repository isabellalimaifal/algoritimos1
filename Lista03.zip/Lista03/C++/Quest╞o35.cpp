#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Desenvolva um programa que alimente uma matriz com n�meros aleat�rios, imprima seus elementos e o resultado da soma dos elementos com �ndice j par.
int main (void) {
	system ("cls");
    setlocale (LC_ALL, "Portuguese");
    int matriz[4][5];
    int linhas = 4;
    int colunas = 5;
    printf ("\n\nEste programa alimenta uma matriz de n�meros aleat�rios, imprime seus elementos e o resultado da soma dos elemntos com �ndice j � par!");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            matriz[i][j] = rand() % 100 + 1;
        }
		}
    
    
    printf("\n\nMatriz:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%3d ", matriz[i][j]);
    }
        printf("\n");
}
    
    int soma = 0;
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j += 2) {
            soma += matriz[i][j];
    }
}
    printf("\n\nSoma dos elementos com �ndice j par: %d\n", soma);
    printf("\n\nObrigado por utilizar nosso programa!");
    system ("Pause");
    return 0;
}
