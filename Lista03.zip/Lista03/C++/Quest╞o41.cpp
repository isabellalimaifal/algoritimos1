#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int m, n;
	printf("\n\nEste programa determina a transposta de uma matriz A qualquer. Ap�s isso, o programa deve verificar se a transposta da matriz � igual a pr�pria matriz!\n");
    printf("\nInforme o n�mero de linhas da matriz: ");
    scanf("%d", &m);

    printf("\nInforme o n�mero de colunas da matriz: ");
    scanf("%d", &n);

    int matriz[m][n];

    printf("\nInforme os elementos da matriz %dx%d: ", m, n);
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("\nMatriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }
	
	printf("\nMatriz informada pelo usu�rio:\n [ ");
    for (int i = 0; i < m; i++) { 
        for (int j = 0; j < n; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf(" ]\n");
    }
	
    int transposta[n][m];
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            transposta[j][i] = matriz[i][j];
        }
    }

    int igual = 1;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (matriz[i][j] != transposta[i][j]) {
                igual = 0;
                break;
            }
        }
        if (!igual) {
            break;
        }
    }

    if (igual) {
        printf("\nA matriz � igual � sua transposta.\n");
    } else {
        printf("\nA matriz n�o � igual � sua transposta.\n");
    }
	printf("\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
