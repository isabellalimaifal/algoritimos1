#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tamanhoB, tamanhoC;
	printf ("\nEste programa determina os elementos de A!\n");
	
    // Solicita ao usu�rio o tamanho do vetor B
    printf("\nInforme o tamanho do vetor B: ");
    scanf("%d", &tamanhoB);

    // Declara��o e aloca��o do vetor B
    int* vetorB = (int*)malloc(tamanhoB * sizeof(int));

    // Leitura dos elementos do vetor B
    printf("\nInforme os elementos do vetor B: \n");
    for (int i = 0; i < tamanhoB; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &vetorB[i]);
    }

    // Solicita ao usu�rio o tamanho do vetor C
    printf("\nInforme o tamanho do vetor C: ");
    scanf("%d", &tamanhoC);

    // Declara��o e aloca��o do vetor C
    int* vetorC = (int*)malloc(tamanhoC * sizeof(int));

    // Leitura dos elementos do vetor C
    printf("\nInforme os elementos do vetor C: \n");
    for (int i = 0; i < tamanhoC; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &vetorC[i]);
    }

    // Vetor A ter� o tamanho do maior entre B e C
    int tamanhoA = (tamanhoB > tamanhoC) ? tamanhoB : tamanhoC;

    // Declara��o e aloca��o do vetor A
    int* vetorA = (int*)malloc(tamanhoA * sizeof(int));

    // Verifica se os tamanhos de B e C s�o iguais
    int tamanhosIguais = (tamanhoB == tamanhoC) ? 1 : 0;

    if (tamanhosIguais) {
        // Calcula o vetor A se os tamanhos de B e C forem iguais
        for (int i = 0; i < tamanhoA; i++) {
            vetorA[i] = vetorC[i] - vetorB[i];
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Imprime os tr�s vetores
    printf("\nVetor B: [");
    for (int i = 0; i < tamanhoB; i++) {
        printf("%d", vetorB[i]);
        if (i < tamanhoB - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    printf("\nVetor C: [");
    for (int i = 0; i < tamanhoC; i++) {
        printf("%d", vetorC[i]);
        if (i < tamanhoC - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    if (tamanhosIguais) {
        printf("\nVetor A: [");
        for (int i = 0; i < tamanhoA; i++) {
            printf("%d", vetorA[i]);
            if (i < tamanhoA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    } else {
        printf("\n\nN�o � poss�vel calcular a soma dos vetores devido a tamanhos diferentes.\n");
    }

    // Libera a mem�ria alocada
    free(vetorB);
    free(vetorC);
    free(vetorA);

    printf("\n\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
