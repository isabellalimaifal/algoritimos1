#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tamanho;
    printf("\nEste programa permite ao usu�rio inserir um vetor de n�meros inteiros e, em seguida, busca por um n�mero espec�fico dentro desse vetor!\n");
    
    // Solicita o tamanho do vetor
    printf("\nDigite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    // Declare o vetor com o tamanho especificado
    int vetor[tamanho];
    
    // Solicita os elementos do vetor com as posi��es
    printf("\nDigite os elementos do vetor:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("Elemento [%d] ", i);
        scanf("%d", &vetor[i]);
    }
    
    printf("\n\n\n");
	system ("Pause");
	system("cls");
    
    // Imprime o vetor na ordem original
    printf("\nVetor Original: [");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", vetor[i]);
        if (i < tamanho - 1) {
            printf("  ");
        }
    }
    printf("]\n");
    
    // Busca um n�mero na estrutura
    int numero;
    printf("\nDigite o n�mero que deseja buscar: ");
    scanf("%d", &numero);
	    
    printf("\n\n");
	system ("Pause");
	system("cls");
	
	// Imprime o vetor na ordem original
    printf("\nVetor Original: [");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", vetor[i]);
        if (i < tamanho - 1) {
            printf("  ");
        }
    }
    printf("]\n");
	
    // Busca e imprime a posi��o de cada repeti��o do n�mero
    int encontrado = 0;
    printf("\nPosi��es do n�mero %d: [", numero);
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] == numero) {
            if (encontrado > 0) {
                printf("  ");
            }
            printf("%d", i);
            encontrado++;
        }
    }
    printf("]\n");

    if (encontrado == 0) {
        printf("\nO n�mero %d n�o foi encontrado no vetor. ", numero);
    }
  	printf("\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
