#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

// Fun��o para ordenar um vetor em ordem crescente (m�todo da sele��o)
void ordenarCrescente(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < tamanho; j++) {
            if (vetor[j] < vetor[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            int temp = vetor[i];
            vetor[i] = vetor[minIndex];
            vetor[minIndex] = temp;
        }
    }
}

// Fun��o para ordenar um vetor em ordem decrescente (m�todo da sele��o invertido)
void ordenarDecrescente(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        int maxIndex = i;
        for (int j = i + 1; j < tamanho; j++) {
            if (vetor[j] > vetor[maxIndex]) {
                maxIndex = j;
            }
        }
        if (maxIndex != i) {
            int temp = vetor[i];
            vetor[i] = vetor[maxIndex];
            vetor[maxIndex] = temp;
        }
    }
}

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tamanho;
    printf("\n\nEste programa l� um vetor inteiro e oferece uma maneira conveniente de encontrar a posi��o de um n�mero na estrutura de dados em diferentes ordens (crescente e decrescente) e permite que voc� visualize a estrutura organizada de acordo com essas ordens!\n");
    
    // Solicita o tamanho do vetor
    printf("\nDigite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    // Declare o vetor com o tamanho especificado
    int vetor[tamanho];
    
    // Solicita os elementos do vetor
    printf("\nDigite os elementos do vetor: \n");
    for (int i = 0; i < tamanho; i++) {
        printf("Elemento [%d] ", i);
        scanf("%d", &vetor[i]);
    }
    
    // Imprime o vetor na ordem original
    printf("\nVetor Original: [");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", vetor[i]);
        if (i < tamanho - 1) {
            printf("  ");
        }
    }
    printf("]\n");
    
    // Busca um n�mero na estrutura
    int numero;
    printf("\nDigite o n�mero que deseja buscar: ");
    scanf("%d", &numero);

    // Procura a posi��o do n�mero quando o vetor est� em ordem crescente
    int posicaoCrescente = -1;
    int vetorCrescente[tamanho];
    for (int i = 0; i < tamanho; i++) {
        vetorCrescente[i] = vetor[i];
    }
    ordenarCrescente(vetorCrescente, tamanho); // Ordena em ordem crescente

    for (int i = 0; i < tamanho; i++) {
        if (vetorCrescente[i] == numero) {
            posicaoCrescente = i;
            break;
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Imprime o vetor em ordem crescente
    printf("\nVetor Crescente: [");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", vetorCrescente[i]);
        if (i < tamanho - 1) {
            printf("  ");
        }
    }
    printf("]");

    // Procura a posi��o do n�mero quando o vetor est� em ordem decrescente
    int posicaoDecrescente = -1;
    int vetorDecrescente[tamanho];
    for (int i = 0; i < tamanho; i++) {
        vetorDecrescente[i] = vetor[i];
    }
    ordenarDecrescente(vetorDecrescente, tamanho); // Ordena em ordem decrescente

    for (int i = 0; i < tamanho; i++) {
        if (vetorDecrescente[i] == numero) {
            posicaoDecrescente = i;
            break;
        }
    }
	
    // Imprime o vetor em ordem decrescente
    printf("\nVetor Decrescente: [");
    for (int i = 0; i < tamanho; i++) {
        printf("%d", vetorDecrescente[i]);
        if (i < tamanho - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    // Imprime a posi��o do n�mero nas duas ordens
    if (posicaoCrescente != -1) {
        printf("\nPosi��o do n�mero %d em ordem crescente: %d", numero, posicaoCrescente);
    } else {
        printf("\nO n�mero %d n�o foi encontrado em ordem crescente.", numero);
    }
    if (posicaoDecrescente != -1) {
        printf("\nPosi��o do n�mero %d em ordem decrescente: %d", numero, posicaoDecrescente);
    } else {
        printf("\nO n�mero %d n�o foi encontrado em ordem decrescente.\n", numero);
    }
	printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
