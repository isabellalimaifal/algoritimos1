#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxD = 100; // Tamanho m�ximo da matriz

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int linhas, colunas, numero;
	printf("\nEste programa permite inserir uma matriz A de n�meros inteiros e, em seguida, realizar a busca de um n�mero inteiro espec�fico na matriz. Se houver repeti��es desse n�mero na matriz, o programa identificar� a posi��o de cada repeti��o!\n");
 	
    // Solicita o tamanho da matriz
    printf("\nDigite o n�mero de linhas da matriz A: ");
    scanf("%d", &linhas);
    printf("\nDigite o n�mero de colunas da matriz A: ");
    scanf("%d", &colunas);

    // Declara a matriz
    int matriz[maxD][maxD];
    
    // Solicita os elementos da matriz com a formata��o "Elemento : [i][j]"
    printf("\nDigite os elementos da matriz A (%d x %d):\n", linhas, colunas);
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("Elemento : [%d][%d] : ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    // Solicita o n�mero a ser buscado na matriz
    printf("\nDigite o n�mero que deseja buscar na matriz A: ");
    scanf("%d", &numero);

	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Realiza a busca e identifica a posi��o de cada repeti��o do n�mero
    int encontrado = 0;
    printf("\nPosi��es do n�mero %d na matriz A:\n", numero);
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (matriz[i][j] == numero) {
                printf("[%d][%d]\n", i + 1, j + 1);
                encontrado++;
            }
        }
    }

    if (encontrado == 0) {
        printf("\nO n�mero %d n�o foi encontrado na matriz A.\n", numero);
    }

    // Imprime os elementos informados pelo usu�rio em formato de coluna e linha com colchetes
    printf("\nMatriz A informada pelo usu�rio :\n");
    for (int i = 0; i < linhas; i++) {
        printf("[");
        for (int j = 0; j < colunas; j++) {
            printf("%d", matriz[i][j]);
            if (j < colunas - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }
  	printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
