#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxV = 10; // N�mero m�ximo de vetores
const int maxE = 100; // N�mero m�ximo de elementos em cada vetor

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int vetores[maxV][maxE] = {{0}}; // Inicializa todos os vetores com zeros
    int numVetores = 0;
    int tamanhoVetor[maxV] = {0}; // Armazena os tamanhos dos vetores
    printf("\nEste programa oferece uma funcionalidade flex�vel de soma de vetores, permitindo somar quantas cole��es de n�meros desejar, desde que seja poss�vel realizar a opera��o. O programa apresenta um menu de op��es!\n");
        while (1) {
        int opcao;
        printf("\nMenu de Op��es:\n");
        printf("\n1. Adicionar um vetor\n");
        printf("\n2. Somar vetores\n");
        printf("\n3. Sair\n");
        printf("\nEscolha uma op��o: ");
        scanf("%d", &opcao);
        
        if (opcao == 1) {
            if (numVetores < maxV) {
                int tamanho;
                printf("\nDigite o tamanho do vetor: ");
                scanf("%d", &tamanho);
                
                if (tamanho <= maxE) {
                    printf("\nDigite os elementos do vetor: \n");
                    for (int i = 0; i < tamanho; i++) {
                        printf("Elemento [%d][%d]: ", numVetores, i);
                        scanf("%d", &vetores[numVetores][i]);

                    }
                    
                    tamanhoVetor[numVetores] = tamanho;
                    numVetores++;
                    
                } else {
                    printf("\nO tamanho do vetor excede o limite permitido.\n");
                }
            } else {
                printf("\nN�mero m�ximo de vetores atingido.\n");
            }
        } else if (opcao == 2) {
            if (numVetores < 2) {
                printf("\n� necess�rio ter pelo menos dois vetores para realizar a soma.\n");
            } else {
                // Verifica se os tamanhos dos vetores s�o compat�veis
                int tamanho = tamanhoVetor[0];
                int tamanhosCompativeis = 1;
                for (int i = 1; i < numVetores; i++) {
                    if (tamanhoVetor[i] != tamanho) {
                        tamanhosCompativeis = 0;
                        break;
                    }
                }
                
                if (tamanhosCompativeis) {
                    int resultado[maxE] = {0};
                    for (int i = 0; i < tamanho; i++) {
                        for (int j = 0; j < numVetores; j++) {
                            resultado[i] += vetores[j][i];
                        }
                    }
                    
                    printf("\n\n\n");
					system ("Pause");
					system("cls");
                    
                    // Imprime o resultado da soma
                    printf("\nResultado da soma:\n[");
                    for (int i = 0; i < tamanho; i++) {
                        printf("%d", resultado[i]);
                        if (i < tamanho - 1) {
                            printf("  ");
                        }
                    }
                    printf("]\n");
                    
                    // Imprime os elementos dos vetores
                    printf("\nElementos dos vetores:\n");
                    for (int i = 0; i < numVetores; i++) {
                        printf("Vetor %d: [", i + 1);
                        for (int j = 0; j < tamanho; j++) {
                            printf("%d", vetores[i][j]);
                            if (j < tamanho - 1) {
                                printf("  ");
                            }
                        }
                        printf("]\n");
                    }
                } else {
                    printf("\nOs tamanhos dos vetores n�o s�o compat�veis para realizar a soma.\n");
                }
            }
        } else if (opcao == 3) {
            break;
        } else {
            printf("\nOp��o inv�lida. Tente novamente.\n");
        }
    }
  	printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
