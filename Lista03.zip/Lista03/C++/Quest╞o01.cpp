#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tam1, tam2, tam3;
	printf("\nEste programa l� os dados de tr�s vetores de n�meros inteiros, e imprime o resultado da soma dos tr�s juntos!\n");
	
    // Solicita ao usu�rio o tamanho do primeiro vetor
    printf("\nDigite o tamanho do primeiro vetor: ");
    scanf("%d", &tam1);

    int v1[tam1];

    printf("\nDigite os elementos do primeiro vetor: \n");
    for (int i = 0; i < tam1; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &v1[i]);
    }

    // Solicita ao usu�rio o tamanho do segundo vetor
    printf("\nDigite o tamanho do segundo vetor: ");
    scanf("%d", &tam2);

    int v2[tam2];

    printf("\n\nDigite os elementos do segundo vetor: \n");
    for (int i = 0; i < tam2; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &v2[i]);
    }

    // Solicita ao usu�rio o tamanho do terceiro vetor
    printf("\nDigite o tamanho do terceiro vetor: ");
    scanf("%d", &tam3);

    int v3[tam3];

    printf("\nDigite os elementos do terceiro vetor: \n");
    for (int i = 0; i < tam3; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &v3[i]);
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Imprime os tr�s vetores, independentemente dos tamanhos
    printf("\n\nPrimeiro vetor: [");
    for (int i = 0; i < tam1; i++) {
        printf("%d", v1[i]);
        if (i < tam1 - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    printf("\nSegundo vetor: [");
    for (int i = 0; i < tam2; i++) {
        printf("%d", v2[i]);
        if (i < tam2 - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    printf("\nTerceiro vetor: [");
    for (int i = 0; i < tam3; i++) {
        printf("%d", v3[i]);
        if (i < tam3 - 1) {
            printf("  ");
        }
    }
    printf("]\n");

    // Verifica se os tamanhos dos vetores s�o iguais
    int tamI = (tam1 == tam2 && tam1 == tam3) ? 1 : 0;

    if (tamI) {
        int tamR = tam1;

        int vResultado[tamR];

        for (int i = 0; i < tamR; i++) {
            vResultado[i] = v1[i] + v2[i] + v3[i];
        }

        printf("\nVetor resultado da soma: [");
        for (int i = 0; i < tamR; i++) {
            printf("%d", vResultado[i]);
            if (i < tamR - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    } else {
        printf("\nOs vetores t�m tamanhos diferentes, a soma n�o pode ser calculada.\n");
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}

