#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Desenvolva um programa que realize a multplica��o de duas matrizes quadradas de ordem n, imprima as duas matrizes originais, a matriz resultado e carregue um vetor/array/lista com os elementos da diagonal secund�ria.

int main (void){
	
	int n;
	
	printf ("\n\nEste programa realiza a multiplica��o de duas matrizes quadradas de ordem n, imprime as duas matrizes originais, a matriz resultado e carrega um vetor com os elementos da diagonal secund�ria!");
    printf ("\n\nInforme a ordem da matriz quadrada: ");
    scanf ("%d", &n);

    int A[n][n], B[n][n], C[n][n];

    printf ("\n\nInforme os elementos da matriz A: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf ("%d", &A[i][j]);
        }
    }
    printf ("\n\nInforme os elementos da matriz B: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf ("%d", &B[i][j]);
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i][j] = 0;
            for (int k = 0; k < n; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    printf ("\n\nMatriz A: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf ("%d ", A[i][j]);
        }
    }

    printf ("\n\nMatriz B: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf ("%d ", B[i][j]);
        }
    }
    printf ("\n\nMatriz Resultado (C): ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf ("%d ", C[i][j]);
        }
    }
    int diagonalSecundaria[n];
    for (int i = 0; i < n; i++) {
        diagonalSecundaria[i] = C[i][n - 1 - i];
    }
    printf ("\n\nElementos da diagonal secund�ria de C: ");
    for (int i = 0; i < n; i++) {
        printf ("%d ", diagonalSecundaria[i]);
    }
    printf ("\n\nObrigado por utilizar nosso programa!\n");
    system ("Pause");
    return 0;
}
