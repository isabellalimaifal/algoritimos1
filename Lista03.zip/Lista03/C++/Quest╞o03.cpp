#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    int tamanhoA, tamanhoB;
    printf("\nEste programa determina 2.(3.A + 5.B), A e B, caso seja poss�vel.!\n");

    // Solicita o tamanho do vetor A
    printf("\nDigite o tamanho do vetor A: ");
    scanf("%d", &tamanhoA);
    
    // Solicita o tamanho do vetor B
    printf("\nDigite o tamanho do vetor B: ");
    scanf("%d", &tamanhoB);
    
    // Declare os vetores A, B e Resultado com os tamanhos especificados
    int A[tamanhoA];
    int B[tamanhoB];
    int Resultado[tamanhoA];
    
    // Solicita os elementos do vetor A
  	printf("\nDigite os elementos do vetor A: \n");
    for (int i = 0; i < tamanhoA; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &A[i]);
    }

    // Solicita os elementos do vetor B
    printf("\nDigite os elementos do vetor B: \n");
    for (int i = 0; i < tamanhoB; i++) {
        printf("Elemento [%d]: ", i);
        scanf("%d", &B[i]);
    }

    printf("\n\n\n");
	system ("Pause");
	system("cls");
    
    // Imprime os vetores A e B 
    printf("\nVetor A: [");
    for (int i = 0; i < tamanhoA; i++) {
        printf("%d", A[i]);
        if (i < tamanhoA - 1) {
            printf("  ");
        }
    }
    printf("]\n");
    
    printf("\nVetor B: [");
    for (int i = 0; i < tamanhoB; i++) {
        printf("%d", B[i]);
        if (i < tamanhoB - 1) {
            printf("  ");
        }
    }
    printf("]\n");
    
    // Verifica se os vetores t�m o mesmo tamanho para calcular
    if (tamanhoA != tamanhoB) {
        printf("\nOs vetores A e B n�o t�m o mesmo tamanho. N�o � poss�vel calcular a soma.\n");
    } else {
        // Calcula os resultados e armazena em vetor Resultado
        for (int i = 0; i < tamanhoA; i++) {
            Resultado[i] = 2 * (3 * A[i] + 5 * B[i]);
        }
        
        // Imprime o vetor de resultados
        printf("\nVetor C: [");
        for (int i = 0; i < tamanhoA; i++) {
            printf("%d", Resultado[i]);
            if (i < tamanhoA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
