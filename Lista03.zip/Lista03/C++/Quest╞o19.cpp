#include <stdio.h>
#include <stdlib.h>

int main(void) {
    system("cls");
    int i, j, linhasA, colunasA;

    printf("Este programa carrega e imprime uma matriz A[i][j] e determina a soma de cada linha e coluna.\n");
    printf("\n\nInforme a quantidade de linhas: ");
    scanf("%d", &linhasA);
    printf("\n\nInforme a quantidade de colunas: ");
    scanf("%d", &colunasA);

    printf("\n\nInforme os elementos da matriz A:\n");

    int A[linhasA][colunasA], somaLinhas[linhasA] = {0}, somaColunas[colunasA] = {0};

    for (i = 0; i < linhasA; i++) {
        for (j = 0; j < colunasA; j++) {
            printf("Informe o elemento na posi��o A[%d][%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }

    printf("\nMatriz A:\n");
    for (i = 0; i < linhasA; i++) {
        for (j = 0; j < colunasA; j++) {
            printf("%d", A[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < linhasA; i++) {
        for (j = 0; j < colunasA; j++) {
            somaLinhas[i] += A[i][j];
            somaColunas[j] += A[i][j];
        }
    }

    printf("\nSoma das Linhas:\n");
    for (i = 0; i < linhasA; i++) {
        printf("Linha %d: %d\n", i + 1, somaLinhas[i]);
    }

    printf("\nSoma das Colunas:\n");
    for (j = 0; j < colunasA; j++) {
        printf("Coluna %d: %d\n", j + 1, somaColunas[j]);
    }

    printf("\nObrigado por utilizar o nosso programa.\n");

    system("Pause");
    return 0;
}
