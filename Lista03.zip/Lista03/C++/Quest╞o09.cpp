#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxD = 100; // Tamanho m�ximo das matrizes

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int linhasA, colunasA, linhasB, colunasB, linhasC, colunasC;
	printf("\nEste programa permite realizar a opera��o em matrizes de n�meros inteiros (A + B) - C, para quaisquer matrizes A, B e C, caso a opera��o seja poss�vel. Al�m disso, o programa determina a soma total dos elementos da matriz resultado da opera��o e imprime todas as matrizes envolvidas!\n");
	
    // Solicita o tamanho da matriz A
    printf("\nDigite o n�mero de linhas da matriz A: ");
    scanf("%d", &linhasA);
    printf("\nDigite o n�mero de colunas da matriz A: ");
    scanf("%d", &colunasA);

    // Solicita o tamanho da matriz B
    printf("\nDigite o n�mero de linhas da matriz B: ");
    scanf("%d", &linhasB);
    printf("\nDigite o n�mero de colunas da matriz B: ");
    scanf("%d", &colunasB);

    // Solicita o tamanho da matriz C
    printf("\nDigite o n�mero de linhas da matriz C: ");
    scanf("%d", &linhasC);
    printf("\nDigite o n�mero de colunas da matriz C: ");
    scanf("%d", &colunasC);

    // Verifica se as matrizes podem ser somadas e subtra�das
    if (linhasA != linhasB || colunasA != colunasB || linhasA != linhasC || colunasA != colunasC) {
        printf("\nAs matrizes A, B e C n�o t�m dimens�es compat�veis para realizar a opera��o.\n");
        return 0;
    }

    // Declara as matrizes A, B, C e a matriz resultante R
    int matrizA[maxD][maxD];
    int matrizB[maxD][maxD];
    int matrizC[maxD][maxD];
    int matrizR[maxD][maxD];
    
    // Solicita os elementos da matriz A
    printf("\nDigite os elementos da matriz A (%d x %d):\n", linhasA, colunasA);
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matrizA[i][j]);
        }
    }

    // Solicita os elementos da matriz B
    printf("\nDigite os elementos da matriz B (%d x %d):\n", linhasB, colunasB);
    for (int i = 0; i < linhasB; i++) {
        for (int j = 0; j < colunasB; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matrizB[i][j]);
        }
    }

    // Solicita os elementos da matriz C
    printf("\nDigite os elementos da matriz C (%d x %d):\n", linhasC, colunasC);
    for (int i = 0; i < linhasC; i++) {
        for (int j = 0; j < colunasC; j++) {
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matrizC[i][j]);
        }
    }
    
    // Realiza a opera��o (A + B) - C e armazena o resultado em R
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            matrizR[i][j] = (matrizA[i][j] + matrizB[i][j]) - matrizC[i][j];
        }
    }

    // Calcula a soma total dos elementos da matriz resultante
    int somaTotal = 0;
    for (int i = 0; i < linhasA; i++) {
        for (int j = 0; j < colunasA; j++) {
            somaTotal += matrizR[i][j];
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    // Imprime as matrizes A, B, C e a matriz resultante R
    printf("\nMatriz A:\n");
    for (int i = 0; i < linhasA; i++) {
        printf("[");
        for (int j = 0; j < colunasA; j++) {
            printf("%d", matrizA[i][j]);
            if (j < colunasA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nMatriz B:\n");
    for (int i = 0; i < linhasB; i++) {
        printf("[");
        for (int j = 0; j < colunasB; j++) {
            printf("%d", matrizB[i][j]);
            if (j < colunasB - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nMatriz C:\n");
    for (int i = 0; i < linhasC; i++) {
        printf("[");
        for (int j = 0; j < colunasC; j++) {
            printf("%d", matrizC[i][j]);
            if (j < colunasC - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }

    printf("\nMatriz Resultante R:\n");
    for (int i = 0; i < linhasA; i++) {
        printf("[");
        for (int j = 0; j < colunasA; j++) {
            printf("%d", matrizR[i][j]);
            if (j < colunasA - 1) {
                printf("  ");
            }
        }
        printf("]\n");
    }
    printf("\nSoma total dos elementos da matriz resultante: %d\n", somaTotal);
  	printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
