#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

const int maxA = 100;
struct Aluno {
    char nome[100];
    double notas[4];
    double media;
};

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
    Aluno alunos[maxA];
    int numAlunos;
	printf("\n\nEste programa l� o nome de n alunos de uma escola e suas respectivas 04 notas. O programa localiza o aluno, suas notas, sua m�dia e determina se foi aprovado (com m�dia igual ou superior ao valor 70,00) ou se foi reprovado!");
    printf("\n\nQuantos alunos deseja cadastrar? ");
    scanf("%d", &numAlunos);

    for (int i = 0; i < numAlunos; ++i) {
        printf("\nInforme o nome do aluno %d: ", i + 1);
        scanf(" %[^\n]", alunos[i].nome);

        printf("\nInforme as 4 notas do aluno (separadas por espa�o): ");
        for (int j = 0; j < 4; ++j) {
            scanf("%lf", &alunos[i].notas[j]);
        }
    }

	printf("\n\n\n");
	system ("Pause");
	system("cls");
	
    for (int i = 0; i < numAlunos; ++i) {
        double somaNotas = 0;
        for (int j = 0; j < 4; ++j) {
            somaNotas += alunos[i].notas[j];
        }
        alunos[i].media = somaNotas / 4;

        printf("\nAluno: %s\n", alunos[i].nome);
        printf("\nNotas: ");
        for (int j = 0; j < 4; ++j) {
            printf("%.2lf ", alunos[i].notas[j]);
        }
        printf("\nM�dia: %.2lf\n", alunos[i].media);

        if (alunos[i].media >= 70.0) {
            printf("\n\nSitua��o: Aprovado\n");
        } else {
            printf("Situa��o: Reprovado\n");
        }
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
