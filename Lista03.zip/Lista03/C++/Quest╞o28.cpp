#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>


//Desenvolva um programa que leia v�rias frases e imprima-as. Ap�s isso, o programa dever� ler uma frase e determina se a frase faz parte do cojunto de frases lidas anteriormente ou n�o.


int main (void) {
    system ("cls");
    setlocale (LC_ALL, "Portuguese");

    int maxfrase = 4;
    int maxcaracter = 20;

    char frases[maxfrase][maxcaracter];
    int numFrases = 0;

    printf ("\n\nEste programa l� v�rias frases e as imprime. Em seguida, o programa l� uma frase e determina se a mesma faz parte do conjunto de frases anteriormente ou n�o!");
    printf ("\n\nDigite v�rias frases:\n");

    while (numFrases < maxfrase) {
        printf ("Frase %d: ", numFrases + 1);
        fgets (frases[numFrases], sizeof(frases[numFrases]), stdin);

        frases[numFrases][strcspn(frases[numFrases], "\n")] = '\0';

        numFrases++;
    }

    printf ("\n\nFrases digitadas:\n");

    for (int i = 0; i < numFrases; i++) {
        printf ("%d: %s\n", i + 1, frases[i]);
    }

    char fraseVerificar[maxcaracter];
    printf ("\n\nDigite a frase a ser verificada: ");
    fgets (fraseVerificar, sizeof(fraseVerificar), stdin);

    fraseVerificar[strcspn(fraseVerificar, "\n")] = '\0';


    int encontrada = 0;
    for (int i = 0; i < numFrases; i++) {
        if (strcmp(fraseVerificar, frases[i]) == 0) {
            encontrada = 1;
            break;
        }
    }

    if (encontrada) {
        printf("\n\nA frase faz parte do conjunto de frases lidas!\n");
    } else {
        printf ("\n\nA frase n�o faz parte do conjunto de frases lidas!\n");
    }

    printf ("\nObrigado por utilizar nosso programa!");
    system ("Pause");
    return 0;
}
