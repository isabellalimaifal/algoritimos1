#include <stdlib.h>
#include <locale.h>
#include <string.h>

//Desenvolva um programa que leia um texto. Ap�s isso, o programa deve proporcionar uma op��o para substituir todas as ocorr�ncias de uma palavra no texto.

int main (void) {
	system ("cls");
    setlocale (LC_ALL, "Portuguese");
    char texto [100];
    char palavraBusca [50];
    char palavraSubstituta [50];
    
    printf ("\n\nEste programa l� um texto. Em seguida, o programa deve proporcionar uma op��o para substituir todas as ocorr�ncias de uma palavra no texto!");
    printf ("\n\nInsisra um texto: ");
    fgets (texto, sizeof(texto), stdin);

    printf ("\n\nInsira a palavra que deseja substituir: ");
    scanf ("%s", palavraBusca);

    printf ("\n\nInsira a palavra substituta: ");
    scanf ("%s", palavraSubstituta);

    int lenTexto = strlen(texto);
    int lenBusca = strlen(palavraBusca);
    int lenSubstituta = strlen(palavraSubstituta);

    for (int i = 0; i < lenTexto; i++) {
        if (strncmp(&texto[i], palavraBusca, lenBusca) == 0) {
            printf ("%s", palavraSubstituta);
            i += lenBusca - 1; // Pula os caracteres da palavra original
        } else {
            printf ("%s", texto[i]);
        }
    }
    printf("\n\nObrigado por utilizar nosso programa!");
    system ("Pause");
    return 0;
}
