#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

const int maxL = 100;
const int maxC = 100;

void imprimirMatriz(int matriz[][maxC], int linhas, int colunas) {
    for (int i = 0; i < linhas; ++i) {
        printf("[ ");
        for (int j = 0; j < colunas; ++j) {
            printf("%d ", matriz[i][j]);
        }
        printf("]\n");
    }
}

bool comutam(int matrizA[][maxC], int matrizB[][maxC], int linhas, int colunas) {
    // Verifica se A * B � igual a B * A
    int resultadoAB[maxL][maxC];
    int resultadoBA[maxL][maxC];

    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            resultadoAB[i][j] = 0;
            resultadoBA[i][j] = 0;

            for (int k = 0; k < colunas; ++k) {
                resultadoAB[i][j] += matrizA[i][k] * matrizB[k][j];
                resultadoBA[i][j] += matrizB[i][k] * matrizA[k][j];
            }
        }
    }

    // Verifica se as matrizes A * B e B * A s�o iguais
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            if (resultadoAB[i][j] != resultadoBA[i][j]) {
                return false;
            }
        }
    }

    return true;
}

int main() {
	system("cls");
    setlocale(LC_ALL, "Portuguese");
    int linhas, colunas;
	printf("\n\nEste programa verifica se duas matrizes A e B comutam!\n");
    printf("\nInforme o n�mero de linhas das matrizes: ");
    scanf("%d", &linhas);
    printf("\nInforme o n�mero de colunas das matrizes: ");
    scanf("%d", &colunas);

    int matrizA[maxL][maxC];
    int matrizB[maxL][maxC];

	printf("\n\n\n");
	system ("Pause");
	system("cls");

    printf("\nInforme os elementos da matriz A: \n");
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            printf("\nMatriz A[%d][%d]: ", i, j);
            scanf("%d", &matrizA[i][j]);
        }
    }

    printf("\nInforme os elementos da matriz B: \n");
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            printf("\nMatriz B[%d][%d]: ", i, j);
            scanf("%d", &matrizB[i][j]);
        }
    }
	
	printf("\n\n\n");
	system ("Pause");
	system("cls");
    printf("\nMatriz A: \n");
    imprimirMatriz(matrizA, linhas, colunas);

    printf("\nMatriz B: \n");
    imprimirMatriz(matrizB, linhas, colunas);

    if (comutam(matrizA, matrizB, linhas, colunas)) {
        printf("\nAs matrizes A e B comutam.\n");
    } else {
        printf("\nAs matrizes A e B n�o comutam.\n");
    }
    printf("\n\nObrigado por utilizar nosso programa!\n");
    system("Pause");
    return 0;
}
