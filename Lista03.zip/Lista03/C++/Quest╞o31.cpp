#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <iostream>
#include <cstring>
using namespace std;

int main() {
    system("cls");
    setlocale(LC_ALL, "Portuguese");
	char texto[1000];
    char letra;
    int contador = 0;
	printf("\n\nEste programa l� textos por linha. Ap�s exibir o texto, o programa determina a quantidade de uma determinada letra digitada!\n");
    printf("\nDigite um texto (at� 999 caracteres): ");
    cin.ignore(); 
    cin.getline(texto, sizeof(texto));

    printf("\nTexto digitado: %s \n", texto);

    printf("\n\nDigite uma letra para contar sua ocorr�ncia no texto: ");
    scanf("%c", &letra);

    for (int i = 0; i < strlen(texto); i++) {
        if (texto[i] == letra) {
            contador++;
        }
    }

    printf("\nA letra '%c' ocorre %d vezes no texto.\n", letra, contador);
    printf("\n\nObrigado por utilizar nosso programa!\n\n");
    system("Pause");
    return 0;
}
