#include <stdio.h>
#include <locale.h>

char tabuleiro[3][3];
char jogadorAtual = 'X';

void imprimirTabuleiro() {
    printf("\n  1 2 3\n");
    for (int i = 0; i < 3; i++) {
        printf("%d ", i + 1);
        for (int j = 0; j < 3; j++) {
            printf("%c ", tabuleiro[i][j]);
        }
        printf("\n");
    }
}

bool verificarVitoria() {
    for (int i = 0; i < 3; i++) {
        if (tabuleiro[i][0] == jogadorAtual && tabuleiro[i][1] == jogadorAtual && tabuleiro[i][2] == jogadorAtual)
            return true;
        if (tabuleiro[0][i] == jogadorAtual && tabuleiro[1][i] == jogadorAtual && tabuleiro[2][i] == jogadorAtual)
            return true;
    }

    if (tabuleiro[0][0] == jogadorAtual && tabuleiro[1][1] == jogadorAtual && tabuleiro[2][2] == jogadorAtual)
        return true;
    if (tabuleiro[0][2] == jogadorAtual && tabuleiro[1][1] == jogadorAtual && tabuleiro[2][0] == jogadorAtual)
        return true;

    return false;
}

bool verificarEmpate() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (tabuleiro[i][j] != 'X' && tabuleiro[i][j] != 'O') {
                return false;
            }
        }
    }
    return true;
}

int main() {
    setlocale(LC_ALL, "Portuguese");
    int linha, coluna;
    printf("\n\nEste programa permite que o usu�rio jogue o jogo da velha, exibindo o resultado final, relatando quem venceu a partida!");
    printf("\nBem-vindo ao Jogo da Velha!\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            tabuleiro[i][j] = ' ';
        }
    }
    while (1) {
        imprimirTabuleiro();
        printf("\n\nJogador %c, digite a linha (1-3) e coluna (1-3) da sua jogada (ex: 2 1): ", jogadorAtual);
        scanf("%d %d", &linha, &coluna);

        if (linha < 1 || linha > 3 || coluna < 1 || coluna > 3 || tabuleiro[linha - 1][coluna - 1] != ' ') {
            printf("\n\nJogada inv�lida. Tente novamente.\n");
            continue;
        }

        tabuleiro[linha - 1][coluna - 1] = jogadorAtual;

        if (verificarVitoria()) {
            imprimirTabuleiro();
            printf("\nJogador %c venceu! Parab�ns!\n", jogadorAtual);
            break;
        }

        if (verificarEmpate()) {
            imprimirTabuleiro();
            printf("\nO jogo empatou. Empate!\n");
            break;
        }

        jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
    }
    printf("\n\nObrigado por utilizar nosso programa!\n\n");
    return 0;
}

