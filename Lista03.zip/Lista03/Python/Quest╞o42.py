import os
def imprimir_matriz(matriz, linhas, colunas):
    for i in range(linhas):
        print("[", end=" ")
        for j in range(colunas):
            print(matriz[i][j], end=" ")
        print("]")

def comutam(matrizA, matrizB, linhas, colunas):
    resultado_AB = [[0] * maxC for _ in range(maxL)]
    resultado_BA = [[0] * maxC for _ in range(maxL)]

    for i in range(linhas):
        for j in range(colunas):
            resultado_AB[i][j] = 0
            resultado_BA[i][j] = 0

            for k in range(colunas):
                resultado_AB[i][j] += matrizA[i][k] * matrizB[k][j]
                resultado_BA[i][j] += matrizB[i][k] * matrizA[k][j]

    for i in range(linhas):
        for j in range(colunas):
            if resultado_AB[i][j] != resultado_BA[i][j]:
                return False

    return True

print("\n\nEste programa verifica se duas matrizes A e B comutam!\n")
linhas = int(input("\nInforme o número de linhas e colunas das matrizes: "))
colunas = int(input())

matrizA = [[0] * maxC for _ in range(maxL)]
matrizB = [[0] * maxC for _ in range(maxL)]

print("\nInforme os elementos da matriz A: ")
for i in range(linhas):
    for j in range(colunas):
        matrizA[i][j] = int(input(f"\nMatriz A[{i}][{j}]: "))

print("\nInforme os elementos da matriz B: ")
for i in range(linhas):
    for j in range(colunas):
        matrizB[i][j] = int(input(f"\nMatriz B[{i}][{j}]: "))

print("\nMatriz A: ")
imprimir_matriz(matrizA, linhas, colunas)

print("\nMatriz B: ")
imprimir_matriz(matrizB, linhas, colunas)

if comutam(matrizA, matrizB, linhas, colunas):
    print("\nAs matrizes A e B comutam.\n")
else:
    print("\nAs matrizes A e B não comutam.\n")

print("\nObrigado por utilizar nosso programa!")
os.system("Pause")
