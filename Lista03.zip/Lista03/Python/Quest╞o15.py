import os
def main():
    print("Esse programa possibilita o usuário jogar xadrez.")
    rodadas = int(input("Digite o número de rodadas: "))

    equipes = [[0] * rodadas for _ in range(5)]
    idades = [0] * 5
    pontuacoes = [0] * 5

    for i in range(5):
        idades[i] = int(input(f"Digite a idade do competidor {i + 1}: "))

    for i in range(5):
        for j in range(rodadas):
            while True:
                try:
                    equipes[i][j] = int(input(f"Digite a pontuação da equipe {i + 1} na rodada {j + 1} (0, 1 ou 3): "))
                    if equipes[i][j] not in (0, 1, 3):
                        raise ValueError
                    break
                except ValueError:
                    print("Pontuação inválida! Use 0, 1 ou 3.")

    for i in range(5):
        for j in range(rodadas):
            pontuacoes[i] += equipes[i][j]

    equipe_vencedora = 0

    for i in range(1, 5):
        if pontuacoes[i] > pontuacoes[equipe_vencedora]:
            equipe_vencedora = i

    print("\nClassificação Final:")
    for i in range(5):
        print(f"Equipe {i + 1} - Pontuação Total: {pontuacoes[i]}", end='')
        if i == equipe_vencedora:
            print(" (Equipe Vencedora)")
        else:
            print()

if __name__ == "__main__":
    main()
print("\nObrigado por utilizar o nosso programa.")
