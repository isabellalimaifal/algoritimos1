import os

print("\n\nEste programa lê várias frases e as imprime. Em seguida, o programa lê uma frase e determina se a mesma faz parte do conjunto de frases anteriormente ou não!")
print("\n\nDigite várias frases:\n")

maxfrase = 5  # Defina o número máximo de frases a serem inseridas
numFrases = 0
frases = []

while numFrases < maxfrase:
    frase = input("Frase {}: ".format(numFrases + 1))
    frases.append(frase)
    numFrases += 1

print("\n\nFrases digitadas:\n")

for i in range(numFrases):
    print("{}: {}".format(i + 1, frases[i]))

fraseVerificar = input("\n\nDigite a frase a ser verificada: ")

encontrada = False
for i in range(numFrases):
    if fraseVerificar == frases[i]:
        encontrada = True
        break

if encontrada:
    print("\n\nA frase faz parte do conjunto de frases lidas!")
else:
    print("\n\nA frase não faz parte do conjunto de frases lidas!")

print("\nObrigado por utilizar nosso programa!")
os.system("Pause")
