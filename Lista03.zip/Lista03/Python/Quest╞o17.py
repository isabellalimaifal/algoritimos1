import os

print("\n\nEste programa carrega e imprime uma matriz A 10x10 e determina a soma dos elementos abaixo da diagonal principal da matriz, incluindo os elementos da própria diagonal!\n\n")

print("\n\nInforme os elementos da matriz A!")
A = [[0] * 10 for _ in range(10)]

for i in range(10):
    for j in range(10):
        A[i][j] = int(input("\n\nInforme o elemento na posição A[{}][{}]: ".format(i, j)))

os.system("cls")

print("\n\n\nA = \n")
for i in range(10):
    print("\n")
    for j in range(10):
        print(" {} ".format(A[i][j]), end=" ")

print("\n\n\n")

somaDiagonal = 0
somaAbaixoDaDiagonal = 0

for i in range(10):
    for j in range(10):
        if i == j:
            somaDiagonal += A[i][j]
        elif i > j:
            somaAbaixoDaDiagonal += A[i][j]

print("\n\nA soma dos elementos abaixo da diagonal principal é de:", somaAbaixoDaDiagonal)
print("\nA soma dos elementos da diagonal principal é de:", somaDiagonal)

print("\n\nObrigado por utilizar nosso programa!\n\n")
os.system("Pause")
