import os
class MatrizTridimensional:
    def main():
        print("\nEste programa carrega uma matriz A do tipo m x n x p, em que m, n e p são números inteiros não negativos!")
        m = int(input("Digite o valor de m (linhas): "))
        n = int(input("Digite o valor de n (colunas): "))
        p = int(input("Digite o valor de p (profundidade): "))
        matriz = [[[0 for _ in range(p)] for _ in range(n)] for _ in range(m)]
        print("\nDigite os elementos da matriz {}x{}x{}:".format(m, n, p))

        for i in range(m):
            for j in range(n):
                for k in range(p):
                    matriz[i][j][k] = int(input(f"Matriz[{i}][{j}][{k}]: "))

        print("\nMatriz carregada:")
        MatrizTridimensional.imprimirMatriz(matriz)

        print("\nObrigado por utilizar nosso programa!")

    def imprimirMatriz(matriz):
        print("[", end=" ")
        for i in range(len(matriz)):
            for j in range(len(matriz[0])):
                for k in range(len(matriz[0][0])):
                    print(matriz[i][j][k], end=" ")
        print("]")

if __name__ == "__main__":
    MatrizTridimensional.main()

os.system ("Pause")
