import os
print("\nEste programa permite ao usuário inserir um vetor de números inteiros e, em seguida, busca por um número específico dentro desse vetor!\n")

# Solicita o tamanho do vetor
tamanho = int(input("Digite o tamanho do vetor: "))

# Declare o vetor com o tamanho especificado
vetor = []

# Solicita os elementos do vetor com as posições
print("\nDigite os elementos do vetor:")
for i in range(tamanho):
    elemento = int(input("Elemento [{}]: ".format(i)))
    vetor.append(elemento)

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime o vetor na ordem original
print("\nVetor Original: [", end="")
for i in range(tamanho):
    print(vetor[i], end="")
    if i < tamanho - 1:
        print("  ", end="")
print("]")

# Busca um número na estrutura
numero = int(input("Digite o número que deseja buscar: "))

print("\n\n")
input("Pressione Enter para continuar...")
# Imprime o vetor na ordem original
print("\nVetor Original: [", end="")
for i in range(tamanho):
    print(vetor[i], end="")
    if i < tamanho - 1:
        print("  ", end="")
print("]")

# Busca e imprime a posição de cada repetição do número
encontrado = 0
print("Posições do número {}: [".format(numero), end="")
for i in range(tamanho):
    if vetor[i] == numero:
        if encontrado > 0:
            print("  ", end="")
        print(i, end="")
        encontrado += 1
print("]")

if encontrado == 0:
    print("\nO número {} não foi encontrado no vetor.".format(numero))
print("\nObrigado por utilizar nosso programa!")
os.system ("Pause")
