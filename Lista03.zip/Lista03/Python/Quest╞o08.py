import os
maxD = 100  # Tamanho máximo das matrizes
print("\nEste programa permite a soma de duas matrizes (A e B) e, caso seja possível realizar a operação, determina a matriz transposta da matriz resultante, bem como a soma de seus elementos!\n")

# Solicita o tamanho da matriz A
linhasA = int(input("\nDigite o número de linhas da matriz A: "))
colunasA = int(input("\nDigite o número de colunas da matriz A: "))

# Solicita o tamanho da matriz B
linhasB = int(input("\nDigite o número de linhas da matriz B: "))
colunasB = int(input("\nDigite o número de colunas da matriz B: "))

# Verifica se as matrizes podem ser somadas
if linhasA != linhasB or colunasA != colunasB:
    print("\nAs matrizes A e B não podem ser somadas devido a tamanhos diferentes.\n")
else:
    # Declara as matrizes A, B e a matriz resultante C
    matrizA = [[0] * maxD for _ in range(maxD)]
    matrizB = [[0] * maxD for _ in range(maxD)]
    matrizC = [[0] * maxD for _ in range(maxD)]

    # Solicita os elementos da matriz A
    print("\nDigite os elementos da matriz A ({} x {}): \n".format(linhasA, colunasA))
    for i in range(linhasA):
        for j in range(colunasA):
            matrizA[i][j] = int(input("Elemento [{}][{}]: ".format(i, j)))

    # Solicita os elementos da matriz B
    print("\nDigite os elementos da matriz B ({} x {}):\n".format(linhasB, colunasB))
    for i in range(linhasB):
        for j in range(colunasB):
            matrizB[i][j] = int(input("Elemento [{}][{}]: ".format(i, j)))

    # Realiza a soma das matrizes A e B e armazena o resultado em C
    for i in range(linhasA):
        for j in range(colunasA):
            matrizC[i][j] = matrizA[i][j] + matrizB[i][j]

    # Calcula a transposta da matriz resultante
    matrizTransposta = [[0] * maxD for _ in range(maxD)]
    for i in range(linhasA):
        for j in range(colunasA):
            matrizTransposta[j][i] = matrizC[i][j]

    # Calcula a soma dos elementos da matriz resultante
    somaElementos = sum(sum(matrizC, []))

    print("\n\n\n")
    input("Pressione Enter para continuar...")

    # Imprime as matrizes A, B, C e a transposta da matriz C
    print("\nMatriz A:")
    for i in range(linhasA):
        print("[", end="")
        for j in range(colunasA):
            print(matrizA[i][j], end="")
            if j < colunasA - 1:
                print("  ", end="")
        print("]")

    print("\nMatriz B:")
    for i in range(linhasB):
        print("[", end="")
        for j in range(colunasB):
            print(matrizB[i][j], end="")
            if j < colunasB - 1:
                print("  ", end="")
        print("]")

    print("\nMatriz Resultante C:")
    for i in range(linhasA):
        print("[", end="")
        for j in range(colunasA):
            print(matrizC[i][j], end="")
            if j < colunasA - 1:
                print("  ", end="")
        print("]")

    print("\nTransposta da Matriz C:")
    for i in range(colunasA):
        print("[", end="")
        for j in range(linhasA):
            print(matrizTransposta[i][j], end="")
            if j < linhasA - 1:
                print("  ", end="")
        print("]")

    print("\nSoma dos elementos da matriz resultante:", somaElementos)
    print("\n\nObrigado por utilizar nosso programa!")
os.system ("Pause")
