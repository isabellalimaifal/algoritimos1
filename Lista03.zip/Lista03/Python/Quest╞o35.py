import os

print("\n\nEste programa alimenta uma matriz qualquer da forma (A * B) * C, caso possível. Em seguida, caso possível, o programa deve somar os elementos da diagonal principal e da diagonal secundária. Além disso, o programa deve determinar a diferença entre as somas dos elementos da diagonal principal e da diagonal secundária!")

linhas = int(input("\n\nDigite o número de linhas da matriz: "))
colunas = int(input("\n\nDigite o número de colunas da matriz: "))

if linhas % 3 == 0 and colunas % 3 == 0:
    matriz = []
    print("\n\nDigite os elementos da matriz: ")
    for i in range(linhas):
        linha = []
        for j in range(colunas):
            elemento = int(input())
            linha.append(elemento)
        matriz.append(linha)

    somaDiagonalPrincipal = 0
    somaDiagonalSecundaria = 0
    for i in range(linhas):
        for j in range(colunas):
            if i == j:
                somaDiagonalPrincipal += matriz[i][j]
            if i + j == linhas - 1:
                somaDiagonalSecundaria += matriz[i][j]

    diferenca = abs(somaDiagonalPrincipal - somaDiagonalSecundaria)
    print("\n\nSoma da diagonal principal:", somaDiagonalPrincipal)
    print("\n\nSoma da diagonal secundária:", somaDiagonalSecundaria)
    print("\n\nDiferença entre as somas:", diferenca)
else:
    print("\n\nNão é possível criar uma matriz (A * B) * C com as dimensões fornecidas!")

print("\n\nObrigado por utilizar nosso programa!")
os.system("Pause")

