import os
class MultiplicaMatrizVetor:
    def main():
        print("\nEste programa multiplica um vetor inteiro por uma matriz inteira (caso seja possível), imprime seus elementos e a soma dos elementos da diagonal principal (caso possível)!\n")
        m = int(input("\nInforme o número de linhas da matriz: "))
        n = int(input("\nInforme o número de colunas da matriz: "))
        vetorLado = int(input("\nInforme o tamanho do vetor: "))
        
        if n != vetorLado:
            print("\nA multiplicação não é possível. O número de colunas da matriz deve ser igual ao tamanho do vetor.\n")
            return
        
        matriz = []
        vetor = []
        
        print("\nDigite os elementos da matriz:")
        for i in range(m):
            linha = []
            for j in range(n):
                elemento = int(input(f"A[{i}][{j}]: "))
                linha.append(elemento)
            matriz.append(linha)
        
        print("\nDigite os elementos do vetor:")
        for i in range(vetorLado):
            elemento = int(input(f"V[{i}]: "))
            vetor.append(elemento)
        
        resultado = [0] * m
        somaDiagonal = 0
        
        for i in range(m):
            for j in range(n):
                resultado[i] += matriz[i][j] * vetor[j]
                if i == j:
                    somaDiagonal += matriz[i][j]
        
        print("\nVetor informado pelo usuário: " + str(vetor))
        print("\nElementos da matriz informada pelo usuário:")
        MultiplicaMatrizVetor.printMatrix(matriz)
        print("\nResultado da multiplicação: " + str(resultado))
        print("\nSoma dos elementos da diagonal principal: " + str(somaDiagonal))
        print("\nObrigado por utilizar nosso programa!\n")
    
    def arrayToString(arr):
        return "[" + " ".join(map(str, arr)) + "]"
    
    def printMatrix(matrix):
        for i in range(len(matrix)):
            for j in range(len(matrix[i])):
                print(f"A[{i}][{j}]: [{matrix[i][j]}", end="]")
            print()

if __name__ == "__main__":
    MultiplicaMatrizVetor.main()
                  
os.system("Pause")
