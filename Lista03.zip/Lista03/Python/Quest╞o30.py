import os

print("\n\nEste programa alimenta uma matriz de números aleatórios, imprime seus elementos e o resultado da soma dos elementos com índice j é par!")

linhas = 4
colunas = 5
matriz = [[0] * colunas for _ in range(linhas)]

for i in range(linhas):
    for j in range(colunas):
        matriz[i][j] = int(input("\n\nDigite o valor para matriz[{}][{}]: ".format(i, j)))

print("\n\nMatriz:")
for i in range(linhas):
    for j in range(colunas):
        print(matriz[i][j], end=" ")
    print()

soma = 0
for i in range(linhas):
    for j in range(0, colunas, 2):
        soma += matriz[i][j]

print("\n\nSoma dos elementos com índice j par:", soma)
print("\n\nObrigado por utilizar nosso programa!")

os.system("Pause")
