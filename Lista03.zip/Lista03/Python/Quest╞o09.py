import os
maxD = 100  # Tamanho máximo das matrizes
print("\nEste programa permite realizar a operação em matrizes de números inteiros (A + B) - C, para quaisquer matrizes A, B e C, caso a operação seja possível. Além disso, o programa determina a soma total dos elementos da matriz resultado da operação e imprime todas as matrizes envolvidas!\n")

# Solicita o tamanho da matriz A
linhasA = int(input("\nDigite o número de linhas da matriz A: "))
colunasA = int(input("\nDigite o número de colunas da matriz A: "))

# Solicita o tamanho da matriz B
linhasB = int(input("\nDigite o número de linhas da matriz B: "))
colunasB = int(input("\nDigite o número de colunas da matriz B: "))

# Solicita o tamanho da matriz C
linhasC = int(input("\nDigite o número de linhas da matriz C: "))
colunasC = int(input("\nDigite o número de colunas da matriz C: "))

# Verifica se as matrizes podem ser somadas e subtraídas
if linhasA != linhasB or colunasA != colunasB or linhasA != linhasC or colunasA != colunasC:
    print("\nAs matrizes A, B e C não têm dimensões compatíveis para realizar a operação.\n")
else:
    # Declara as matrizes A, B, C e a matriz resultante R
    matrizA = [[0] * maxD for _ in range(maxD)]
    matrizB = [[0] * maxD for _ in range(maxD)]
    matrizC = [[0] * maxD for _ in range(maxD)]
    matrizR = [[0] * maxD for _ in range(maxD)]

    # Solicita os elementos da matriz A
    print("\nDigite os elementos da matriz A ({} x {}):\n".format(linhasA, colunasA))
    for i in range(linhasA):
        for j in range(colunasA):
            matrizA[i][j] = int(input("Elemento [{}][{}]: ".format(i, j)))

    # Solicita os elementos da matriz B
    print("\nDigite os elementos da matriz B ({} x {}):\n".format(linhasB, colunasB))
    for i in range(linhasB):
        for j in range(colunasB):
            matrizB[i][j] = int(input("Elemento [{}][{}]: ".format(i, j)))

    # Solicita os elementos da matriz C
    print("\nDigite os elementos da matriz C ({} x {}):\n".format(linhasC, colunasC))
    for i in range(linhasC):
        for j in range(colunasC):
            matrizC[i][j] = int(input("Elemento [{}][{}]: ".format(i, j)))

    # Realiza a operação (A + B) - C e armazena o resultado em R
    for i in range(linhasA):
        for j in range(colunasA):
            matrizR[i][j] = (matrizA[i][j] + matrizB[i][j]) - matrizC[i][j]

    # Calcula a soma total dos elementos da matriz resultante
    somaTotal = sum(sum(matrizR, []))

    print("\n\n\n")
    input("Pressione Enter para continuar...")

    # Imprime as matrizes A, B, C e a matriz resultante R
    print("\nMatriz A:")
    for i in range(linhasA):
        print("[", end="")
        for j in range(colunasA):
            print(matrizA[i][j], end="")
            if j < colunasA - 1:
                print("  ", end="")
        print("]")

    print("\nMatriz B:")
    for i in range(linhasB):
        print("[", end="")
        for j in range(colunasB):
            print(matrizB[i][j], end="")
            if j < colunasB - 1:
                print("  ", end="")
        print("]")

    print("\nMatriz C:")
    for i in range(linhasC):
        print("[", end="")
        for j in range(colunasC):
            print(matrizC[i][j], end="")
            if j < colunasC - 1:
                print("  ", end="")
        print("]")

    print("\nMatriz Resultante R:")
    for i in range(linhasA):
        print("[", end="")
        for j in range(colunasA):
            print(matrizR[i][j], end="")
            if j < colunasA - 1:
                print("  ", end="")
        print("]")

    print("\nSoma total dos elementos da matriz resultante:", somaTotal)
    print("\n\nObrigado por utilizar nosso programa!")
os.system ("Pause")
