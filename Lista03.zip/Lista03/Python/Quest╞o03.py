import os
print("\nEste programa determina 2.(3.A + 5.B), A e B, caso seja possível.!\n")

# Solicita o tamanho do vetor A
tamanhoA = int(input("\nDigite o tamanho do vetor A: "))

# Solicita o tamanho do vetor B
tamanhoB = int(input("\nDigite o tamanho do vetor B: "))

# Declare os vetores A, B e Resultado com os tamanhos especificados
A = []
B = []
Resultado = []

# Solicita os elementos do vetor A
print("\nDigite os elementos do vetor A: ")
for i in range(tamanhoA):
    elemento = int(input("Elemento [{}]: ".format(i)))
    A.append(elemento)

# Solicita os elementos do vetor B
print("\nDigite os elementos do vetor B: ")
for i in range(tamanhoB):
    elemento = int(input("Elemento [{}]: ".format(i)))
    B.append(elemento)

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime os vetores A e B
print("\nVetor A: [", end="")
for i in range(tamanhoA):
    print(A[i], end="")
    if i < tamanhoA - 1:
        print("  ", end="")
print("]")

print("\nVetor B: [", end="")
for i in range(tamanhoB):
    print(B[i], end="")
    if i < tamanhoB - 1:
        print("  ", end="")
print("]")

# Verifica se os vetores têm o mesmo tamanho para calcular
if tamanhoA != tamanhoB:
    print("\nOs vetores A e B não têm o mesmo tamanho. Não é possível calcular a soma.\n")
else:
    # Calcula os resultados e armazena em vetor Resultado
    Resultado = [2 * (3 * A[i] + 5 * B[i]) for i in range(tamanhoA)]

    # Imprime o vetor de resultados
    print("\nVetor C: [", end="")
    for i in range(tamanhoA):
        print(Resultado[i], end="")
        if i < tamanhoA - 1:
            print("  ", end="")
    print("]")

print("\nObrigado por utilizar nosso programa!\n")
os.system ("Pause")
