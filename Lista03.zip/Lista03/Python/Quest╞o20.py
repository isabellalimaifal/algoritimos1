import os
print("\n\nEste programa informa a quantidade de vezes que uma letra é encontrada na matriz.\n")
linhas = int(input("Informe a quantidade de linhas: "))
colunas = int(input("Informe a quantidade de colunas: "))

matriz = [[0 for j in range(colunas)] for i in range(linhas)]

print("Digite a matriz de caracteres:")
for i in range(linhas):
    for j in range(colunas):
        matriz[i][j] = input(f"Matriz[{i}][{j}]: ")

letra = input("Informe a letra que deverá ser encontrada: ")

contador = 0

for i in range(linhas):
    for j in range(colunas):
        if matriz[i][j] == letra:
            contador += 1

print(f"A letra '{letra}' foi encontrada {contador} vezes na matriz.")
print("\nObrigado por utilizar o nosso programa!")

