import os
def multiplicar_matrizes(A, linhasA, colunasA, B, linhasB, colunasB, resultado):
    for i in range(linhasA):
        for j in range(colunasB):
            resultado[i][j] = 0.0
            for k in range(colunasA):
                resultado[i][j] += A[i][k] * B[k][j]

def somar_matrizes(A, B, resultado):
    linhasA = len(A)
    colunasA = len(A[0])
    linhasB = len(B)
    colunasB = len(B[0])

    if linhasA == linhasB and colunasA == colunasB:
        for i in range(linhasA):
            for j in range(colunasA):
                resultado[i][j] = A[i][j] + B[i][j]

def main():
    maxL = 100
    maxC = 100

    matrizA = [[0.0 for _ in range(maxC)] for _ in range(maxL)]
    matrizB = [[0.0 for _ in range(maxC)] for _ in range(maxL)]
    matrizC = [[0.0 for _ in range(maxC)] for _ in range(maxL)]
    AB = [[0.0 for _ in range(maxC)] for _ in range(maxL)]

    print("\nEste programa realiza operações com matrizes, incluindo multiplicação, soma e multiplicação por um número real. Também calcula o traço da matriz resultante, se ela for quadrada, utilizando números reais!")

    linhasA = int(input("\nInforme o número de linhas da matriz A: "))
    colunasA = int(input("\nInforme o número de colunas da matriz A: "))

    linhasB = int(input("\nInforme o número de linhas da matriz B: "))
    colunasB = int(input("\nInforme o número de colunas da matriz B: "))

    linhasC = int(input("\nInforme o número de linhas da matriz C: "))
    colunasC = int(input("\nInforme o número de colunas da matriz C: "))

    print("\n\n\n")
    multiplicador = float(input("Informe o valor do multiplicador: "))

    print("Digite os elementos da matriz A (posição A[i][j]):")
    for i in range(linhasA):
        for j in range(colunasA):
            matrizA[i][j] = float(input(f"A[{i}][{j}]: "))

    print("\nDigite os elementos da matriz B (posição B[i][j]):")
    for i in range(linhasB):
        for j in range(colunasB):
            matrizB[i][j] = float(input(f"B[{i}][{j}]: "))

    print("\nDigite os elementos da matriz C (posição C[i][j]):")
    for i in range(linhasC):
        for j in range(colunasC):
            matrizC[i][j] = float(input(f"C[{i}][{j}]: "))

    print("\n\n\n")

    if colunasA == linhasB:
        multiplicar_matrizes(matrizA, linhasA, colunasA, matrizB, linhasB, colunasB, AB)
        linhasC = linhasA
        colunasC = colunasB
    else:
        print("\nA multiplicação de A e B não é possível.")
        return

    resultado = [[0.0 for _ in range(maxC)] for _ in range(maxL)]

    if linhasC == linhasA and colunasC == colunasA:
        somar_matrizes(matrizA, matrizC, resultado)
    else:
        print("\nA soma de A, B e C não é possível.")
        return

    for i in range(linhasC):
        for j in range(colunasC):
            resultado[i][j] *= multiplicador

    traco = 0.0

    if linhasC == colunasC:
        for i in range(linhasC):
            traco += resultado[i][i]

    print("\nMatriz Resultante:")
    for i in range(linhasC):
        print("[", end=" ")
        for j in range(colunasC):
            print(resultado[i][j], end=" ")
        print("]")

    if linhasC == colunasC:
        print("\nTraço da Matriz Resultante: [", traco, "]")
    else:
        print("\nO cálculo do traço não é possível.")

    print("\nObrigado por utilizar nosso programa!")

if __name__ == "__main__":
    main()
    input("Pressione Enter para encerrar...")

os.system("Pause")
