import os
def main():
    max_palavras = 100
    palavras = [""] * max_palavras

    print("\n\nEste programa lê e armazena n palavras e, depois, após digitar uma palavra qualquer, o programa faz a busca da palavra digitada entre as palavras armazenadas!\n")
    n = int(input("Informe o número de palavras a serem inseridas: ")

    # Ler e armazenar as palavras
    for i in range(n):
        palavras[i] = input(f"Informe a palavra #{i + 1}: ")

    palavra_procurada = input("\nInforme a palavra a ser procurada: ")

    ultima_posicao = -1  # Inicializar a última posição como -1 (indicando que não foi encontrada)
    quantidade_repeticoes = 0

    for i in range(n):
        if palavras[i] == palavra_procurada:
            ultima_posicao = i
            quantidade_repeticoes += 1

    print("\n\n\n")

    if ultima_posicao != -1:
        print(f"A palavra '{palavra_procurada}' foi encontrada pela última vez na posição {ultima_posicao + 1}.")
        print(f"Ela aparece {quantidade_repeticoes} vez(es) na lista.")
    else:
        print(f"A palavra '{palavra_procurada}' não foi encontrada na lista.")

    print("\nObrigado por utilizar nosso programa!")

if _name_ == "_main_":
    main()
os.system("Pause")
