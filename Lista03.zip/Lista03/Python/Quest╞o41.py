import os
class TranspostaMatriz:
    def main():
        print("\nEste programa determina a transposta de uma matriz A qualquer. Após isso, o programa deve verificar se a transposta da matriz é igual à própria matriz!")
        m = int(input("\nInforme o número de linhas da matriz: "))
        n = int(input("\nInforme o número de colunas da matriz: "))
        matriz = [[0 for _ in range(n)] for _ in range(m)]
        print(f"Informe os elementos da matriz {m}x{n}:")

        for i in range(m):
            for j in range(n):
                matriz[i][j] = int(input(f"Matriz[{i}][{j}]: "))

        print("\nMatriz informada pelo usuário:")
        TranspostaMatriz.imprimirMatriz(matriz)

        transposta = [[0 for _ in range(m)] for _ in range(n)]
        for i in range(m):
            for j in range(n):
                transposta[j][i] = matriz[i][j]

        igual = True
        for i in range(m):
            for j in range(n):
                if matriz[i][j] != transposta[i][j]:
                    igual = False
                    break
            if not igual:
                break

        if igual:
            print("\nA matriz é igual à sua transposta.")
        else:
            print("\nA matriz não é igual à sua transposta.")
        print("\nObrigado por utilizar nosso programa!")

    @staticmethod
    def imprimirMatriz(matriz):
        print("[", end=" ")
        for i in range(len(matriz)):
            for j in range(len(matriz[0])):
                print(matriz[i][j], end=" ")
            print("]")

if __name__ == "__main__":
    TranspostaMatriz.main()
os.system("Pause")
