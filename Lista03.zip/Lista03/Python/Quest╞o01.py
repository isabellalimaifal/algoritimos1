import os
print("\nEste programa lê os dados de três vetores de números inteiros e imprime o resultado da soma dos três juntos!\n")

# Solicita ao usuário o tamanho do primeiro vetor
tam1 = int(input("Digite o tamanho do primeiro vetor: "))
v1 = []

print("\nDigite os elementos do primeiro vetor:")
for i in range(tam1):
    elemento = int(input("Elemento [{}]: ".format(i)))
    v1.append(elemento)

# Solicita ao usuário o tamanho do segundo vetor
tam2 = int(input("\nDigite o tamanho do segundo vetor: "))
v2 = []

print("\nDigite os elementos do segundo vetor:")
for i in range(tam2):
    elemento = int(input("Elemento [{}]: ".format(i)))
    v2.append(elemento)

# Solicita ao usuário o tamanho do terceiro vetor
tam3 = int(input("\nDigite o tamanho do terceiro vetor: "))
v3 = []

print("\nDigite os elementos do terceiro vetor:")
for i in range(tam3):
    elemento = int(input("Elemento [{}]: ".format(i)))
    v3.append(elemento)

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime os três vetores, independentemente dos tamanhos
print("\nPrimeiro vetor: [", end="")
for i in range(tam1):
    print(v1[i], end="")
    if i < tam1 - 1:
        print("  ", end="")
print("]")

print("\nSegundo vetor: [", end="")
for i in range(tam2):
    print(v2[i], end="")
    if i < tam2 - 1:
        print("  ", end="")
print("]")

print("\nTerceiro vetor: [", end="")
for i in range(tam3):
    print(v3[i], end="")
    if i < tam3 - 1:
        print("  ", end="")
print("]")

# Verifica se os tamanhos dos vetores são iguais
tamI = tam1 == tam2 == tam3

if tamI:
    tamR = tam1
    vResultado = [0] * tamR

    for i in range(tamR):
        vResultado[i] = v1[i] + v2[i] + v3[i]

    print("\nVetor resultado da soma: [", end="")
    for i in range(tamR):
        print(vResultado[i], end="")
        if i < tamR - 1:
            print("  ", end="")
    print("]")
else:
    print("\nOs vetores têm tamanhos diferentes, a soma não pode ser calculada.")

print("\n\nObrigado por utilizar nosso programa!")
os.system ("Pause")

