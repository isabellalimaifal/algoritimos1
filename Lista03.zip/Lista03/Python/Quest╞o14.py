import os
def bubble_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

print("\n\nEste programa lê um vetor inteiro de tamanho n, e ordena-o de maneira crescente, soma seus valores e determina se o resultado da soma é um número par ou ímpar!")
n = int(input("\nInforme o tamanho do vetor: "))
vetor = []
vetor_original = []

print("\nInforme os elementos do vetor: ")
for i in range(n):
    valor = int(input(f"Vetor [{i}]: "))
    vetor.append(valor)
    vetor_original.append(valor)

bubble_sort(vetor)

soma = sum(vetor)

print("\n\n\n")

print("\nVetor ordenado em ordem crescente: [", end=" ")
for valor in vetor:
    print(valor, end=" ")
print("]")

print("\nSoma dos valores:", soma)

if soma % 2 == 0:
    print("\nA soma dos valores é um número par.")
else:
    print("\nA soma dos valores é um número ímpar.")

print("\nVetor original informado: [", end=" ")
for valor in vetor_original:
    print(valor, end=" ")
print("]")

print("\n\nObrigado por utilizar nosso programa!")
os.system("Pause")
