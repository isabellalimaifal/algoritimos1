import os

class Aluno:
    def __init__(self, nome, notas):
        self.nome = nome
        self.notas = notas
        self.media = 0.0

def main():
    print("\n\nEste programa lê o nome de n alunos de uma escola e suas respectivas 04 notas. O programa localiza o aluno, suas notas, sua média e determina se foi aprovado (com média igual ou superior ao valor 70,00) ou se foi reprovado!")
    num_alunos = int(input("\nQuantos alunos deseja cadastrar? "))
    
    alunos = []

    for i in range(num_alunos):
        nome = input(f"\nInforme o nome do aluno {i + 1}: ")
        notas_str = input("\nInforme as 4 notas do aluno (separadas por espaço): ").split()
        notas = [float(nota) for nota in notas_str]
        aluno = Aluno(nome, notas)
        alunos.append(aluno)

    print("\n\n\n")
    print("Alunos cadastrados e suas médias:")

    for aluno in alunos:
        soma_notas = sum(aluno.notas)
        aluno.media = soma_notas / 4

        print(f"\nAluno: {aluno.nome}")
        print("Notas:", end=" ")
        for nota in aluno.notas:
            print(f"{nota:.2f}", end=" ")
        print(f"\nMédia: {aluno.media:.2f}")

        if aluno.media >= 70.0:
            print("\nSituação: Aprovado")
        else:
            print("Situação: Reprovado")

    print("\n\nObrigado por utilizar nosso programa!")

if __name__ == "__main__":
    main()
    os.system("Pause")
