import os

texto = input("\n\nEste programa lê um texto. Em seguida, o programa deve proporcionar uma opção para substituir todas as ocorrências de uma palavra no texto!\n\nInsira um texto: ")
palavraBusca = input("\n\nInsira a palavra que deseja substituir: ")
palavraSubstituta = input("\n\nInsira a palavra substituta: ")
textoModificado = ""

i = 0
lenTexto = len(texto)
lenBusca = len(palavraBusca)

while i < lenTexto:
    if texto[i:i + lenBusca] == palavraBusca:
        textoModificado += palavraSubstituta
        i += lenBusca
    else:
        textoModificado += texto[i]
        i += 1

print("\n\nTexto modificado:", textoModificado)
print("\n\nObrigado por utilizar nosso programa!")
os.system("Pause")
