import os
print("\nEste programa determina o resultado de (3.A + 4.B) – C, para A, B e C vetores, caso seja possível, determinar o resultado final, o programa imprime cada vetor ordenado de maneira crescente!\n")

# Solicita o tamanho do vetor A
tamanhoA = int(input("\nDigite o tamanho do vetor A: "))

# Solicita o tamanho do vetor B
tamanhoB = int(input("\nDigite o tamanho do vetor B: "))

# Solicita o tamanho do vetor C
tamanhoC = int(input("\nDigite o tamanho do vetor C: "))

# Declare os vetores A, B e C com os tamanhos especificados
A = []
B = []
C = []

# Solicita os elementos do vetor A
print("\nDigite os elementos do vetor A:\n")
for i in range(tamanhoA):
    elemento = int(input("Elemento [{}]: ".format(i)))
    A.append(elemento)

# Solicita os elementos do vetor B
print("\nDigite os elementos do vetor B:\n")
for i in range(tamanhoB):
    elemento = int(input("Elemento [{}]: ".format(i)))
    B.append(elemento)

# Solicita os elementos do vetor C
print("\nDigite os elementos do vetor C:\n")
for i in range(tamanhoC):
    elemento = int(input("Elemento [{}]: ".format(i)))
    C.append(elemento)

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime os vetores A, B e C
print("\nVetor A: [", end="")
for i in range(tamanhoA):
    print(A[i], end="")
    if i < tamanhoA - 1:
        print("  ", end="")
print("]")

print("\nVetor B: [", end="")
for i in range(tamanhoB):
    print(B[i], end="")
    if i < tamanhoB - 1:
        print("  ", end="")
print("]")

print("\nVetor C: [", end="")
for i in range(tamanhoC):
    print(C[i], end="")
    if i < tamanhoC - 1:
        print("  ", end="")
print("]")

# Verifica se os tamanhos dos vetores são compatíveis para calcular a expressão
if tamanhoA == tamanhoB and tamanhoB == tamanhoC:
    # Calcula o resultado da expressão para cada elemento
    resultado = [(3 * A[i] + 4 * B[i]) - C[i] for i in range(tamanhoA)]

    # Imprime o vetor de resultados
    print("\nVetor D: [", end="")
    for i in range(tamanhoA):
        print(resultado[i], end="")
        if i < tamanhoA - 1:
            print("  ", end="")
    print("]")

    # Ordena o vetor de resultados em ordem crescente
    ordenar_vetor(resultado)

    # Imprime o vetor de resultados ordenado
    print("\nVetor D Ordenado: [", end="")
    for i in range(tamanhoA):
        print(resultado[i], end="")
        if i < tamanhoA - 1:
            print("  ", end="")
    print("]")
else:
    print("\nOs tamanhos dos vetores A, B e C não são compatíveis para calcular a expressão.\n")

print("\nObrigado por utilizar nosso programa!\n")
os.system ("Pause")
