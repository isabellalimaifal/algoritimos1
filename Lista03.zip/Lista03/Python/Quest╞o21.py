import os
class JogoDaVelha:
    tabuleiro = [[' ' for _ in range(3)] for _ in range(3)]
    jogadorAtual = 'X'

    def main():
        print("\nBem-vindo ao Jogo da Velha!")
        JogoDaVelha.inicializarTabuleiro()
        
        while True:
            JogoDaVelha.imprimirTabuleiro()
            print(f"\nJogador {JogoDaVelha.jogadorAtual}, digite a linha (1-3) e coluna (1-3) da sua jogada (ex: 2 1): ")
            linha, coluna = map(int, input().split())
            linha -= 1
            coluna -= 1

            if linha < 0 or linha > 2 or coluna < 0 or coluna > 2 or JogoDaVelha.tabuleiro[linha][coluna] != ' ':
                print("\nJogada inválida. Tente novamente.")
                continue

            JogoDaVelha.tabuleiro[linha][coluna] = JogoDaVelha.jogadorAtual

            if JogoDaVelha.verificarVitoria():
                JogoDaVelha.imprimirTabuleiro()
                print(f"\nJogador {JogoDaVelha.jogadorAtual} venceu! Parabéns!")
                break

            if JogoDaVelha.verificarEmpate():
                JogoDaVelha.imprimirTabuleiro()
                print("\nO jogo empatou. Empate!")
                break

            JogoDaVelha.jogadorAtual = 'O' if JogoDaVelha.jogadorAtual == 'X' else 'X'

        print("\nObrigado por utilizar nosso programa!")
        input("Pressione Enter para encerrar...")

    def inicializarTabuleiro():
        JogoDaVelha.tabuleiro = [[' ' for _ in range(3)] for _ in range(3)]

    def imprimirTabuleiro():
        print("\n  1 2 3")
        for i in range(3):
            print(i + 1, end=" ")
            for j in range(3):
                print(JogoDaVelha.tabuleiro[i][j], end=" ")
            print()

    def verificarVitoria():
        for i in range(3):
            if JogoDaVelha.tabuleiro[i][0] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[i][1] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[i][2] == JogoDaVelha.jogadorAtual:
                return True
            if JogoDaVelha.tabuleiro[0][i] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[1][i] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[2][i] == JogoDaVelha.jogadorAtual:
                return True

        if JogoDaVelha.tabuleiro[0][0] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[1][1] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[2][2] == JogoDaVelha.jogadorAtual:
            return True
        if JogoDaVelha.tabuleiro[0][2] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[1][1] == JogoDaVelha.jogadorAtual and JogoDaVelha.tabuleiro[2][0] == JogoDaVelha.jogadorAtual:
            return True

        return False

    def verificarEmpate():
        for i in range(3):
            for j in range(3):
                if JogoDaVelha.tabuleiro[i][j] != 'X' and JogoDaVelha.tabuleiro[i][j] != 'O':
                    return False
        return True

if __name__ == "__main__":
    JogoDaVelha.main()
    
os.system ("Pause")
