import os

print("\n\nEste programa carrega e imprime uma matriz A 5x5 e informa de acordo com a matriz que foi digitada se a diagonal dela é triangular inferior ou superior!")
print("\n\nInforme os elementos da matriz A!")

A = [[0] * 5 for _ in range(5)]

for i in range(5):
    for j in range(5):
        A[i][j] = int(input("\n\nInforme o elemento na posição A[{}][{}]: ".format(i, j)))

os.system("clear")

print("\n\n\nA = \n")
for i in range(5):
    print("\n")
    for j in range(5):
        print(" {} ".format(A[i][j]), end=" ")

diagonal = True
superior = True
inferior = True

for i in range(5):
    for j in range(5):
        if i != j and A[i][j] != 0:
            diagonal = False
            if i < j:
                inferior = False
            elif i > j:
                superior = False

if diagonal:
    print("\n\nA matriz é diagonal!\n\n")
elif inferior:
    print("\n\nA matriz é triangular inferior!\n\n")
elif superior:
    print("\n\nA matriz é triangular superior!\n\n")
else:
    print("\n\nA matriz não é diagonal, superior nem triangular inferior!\n\n")

print("\n\nObrigado por utilizar nosso programa!\n\n")
