import os
maxD = 100  # Tamanho máximo da matriz
print("\nEste programa permite inserir uma matriz A de números inteiros e, em seguida, realizar a busca de um número inteiro específico na matriz. Se houver repetições desse número na matriz, o programa identificará a posição de cada repetição!\n")

# Solicita o tamanho da matriz
linhas = int(input("\nDigite o número de linhas da matriz A: "))
colunas = int(input("\nDigite o número de colunas da matriz A: "))

# Declara a matriz
matriz = [[0] * maxD for _ in range(maxD)]

# Solicita os elementos da matriz com a formatação "Elemento : [i][j]"
print("\nDigite os elementos da matriz A ({} x {}):".format(linhas, colunas))
for i in range(linhas):
    for j in range(colunas):
        matriz[i][j] = int(input("\nElemento : [{}][{}] : ".format(i, j)))

# Solicita o número a ser buscado na matriz
numero = int(input("\nDigite o número que deseja buscar na matriz A: "))

print("\n\n\n")
input("Pressione Enter para continuar...")

# Realiza a busca e identifica a posição de cada repetição do número
encontrado = 0
print("\nPosições do número {} na matriz A:".format(numero))
for i in range(linhas):
    for j in range(colunas):
        if matriz[i][j] == numero:
            print("[{}][{}]".format(i + 1, j + 1))
            encontrado += 1

if encontrado == 0:
    print("\nO número {} não foi encontrado na matriz A.".format(numero))

# Imprime os elementos informados pelo usuário em formato de coluna e linha com colchetes
print("\nMatriz A informada pelo usuário :")
for i in range(linhas):
    print("[", end="")
    for j in range(colunas):
        print(matriz[i][j], end="")
        if j < colunas - 1:
            print("  ", end="")
    print("]")

print("\n\nObrigado por utilizar nosso programa!")

os.system ("Pause")
