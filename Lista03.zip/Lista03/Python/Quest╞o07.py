import os
maxV = 10  # Número máximo de vetores
maxE = 100  # Número máximo de elementos em cada vetor
vetores = [[0] * maxE for _ in range(maxV)]
numVetores = 0
tamanhoVetor = [0] * maxV

print("\nEste programa oferece uma funcionalidade flexível de soma de vetores, permitindo somar quantas coleções de números desejar, desde que seja possível realizar a operação. O programa apresenta um menu de opções!\n")

while True:
    opcao = int(input("\nMenu de Opções:\n\n1. Adicionar um vetor\n2. Somar vetores\n3. Sair\nEscolha uma opção: "))

    if opcao == 1:
        if numVetores < maxV:
            tamanho = int(input("\nDigite o tamanho do vetor: "))

            if tamanho <= maxE:
                print("\nDigite os elementos do vetor:")
                vetores[numVetores][:tamanho] = [int(input("Elemento [{}][{}]: ".format(numVetores, i))) for i in range(tamanho)]

                tamanhoVetor[numVetores] = tamanho
                numVetores += 1
            else:
                print("\nO tamanho do vetor excede o limite permitido.")
        else:
            print("\nNúmero máximo de vetores atingido.")
    elif opcao == 2:
        if numVetores < 2:
            print("\nÉ necessário ter pelo menos dois vetores para realizar a soma.")
        else:
            # Verifica se os tamanhos dos vetores são compatíveis
            tamanho = tamanhoVetor[0]
            tamanhosCompativeis = all(tamanhoVetor[i] == tamanho for i in range(1, numVetores))

            if tamanhosCompativeis:
                resultado = [0] * maxE
                for i in range(tamanho):
                    for j in range(numVetores):
                        resultado[i] += vetores[j][i]

                print("\n\n\n")
                input("Pressione Enter para continuar...")  # Substitui a função pressAnyKeyToContinue

                # Imprime o resultado da soma
                print("\nResultado da soma: [", end="")
                for i in range(tamanho):
                    print(resultado[i], end="")
                    if i < tamanho - 1:
                        print("  ", end="")
                print("]")

                # Imprime os elementos dos vetores
                print("\nElementos dos vetores:")
                for i in range(numVetores):
                    print("\nVetor {}: [".format(i + 1), end="")
                    for j in range(tamanho):
                        print(vetores[i][j], end="")
                        if j < tamanho - 1:
                            print("  ", end="")
                    print("]")
            else:
                print("\nOs tamanhos dos vetores não são compatíveis para realizar a soma.")
    elif opcao == 3:
        break
    else:
        print("\nOpção inválida. Tente novamente.")

print("\n\nObrigado por utilizar nosso programa!\n")
