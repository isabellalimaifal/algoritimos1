import os
def ordenar_crescente(vetor):
    vetor.sort()

def ordenar_decrescente(vetor):
    vetor.sort(reverse=True)

print("\n\nEste programa lê um vetor inteiro e oferece uma maneira conveniente de encontrar a posição de um número na estrutura de dados em diferentes ordens (crescente e decrescente) e permite que você visualize a estrutura organizada de acordo com essas ordens!\n")

# Solicita o tamanho do vetor
tamanho = int(input("\nDigite o tamanho do vetor: "))

# Declare o vetor com o tamanho especificado
vetor = []

# Solicita os elementos do vetor
print("\nDigite os elementos do vetor")
for i in range(tamanho):
    elemento = int(input("Elemento [{}]: ".format(i)))
    vetor.append(elemento)

# Imprime o vetor na ordem original
print("\nVetor Original: [", end="")
for i in range(tamanho):
    print(vetor[i], end="")
    if i < tamanho - 1:
        print("  ", end="")
print("]")

# Busca um número na estrutura
numero = int(input("\nDigite o número que deseja buscar: "))

# Procura a posição do número quando o vetor está em ordem crescente
posicaoCrescente = -1
vetorCrescente = vetor.copy()
ordenar_crescente(vetorCrescente)  # Ordena em ordem crescente

for i in range(tamanho):
    if vetorCrescente[i] == numero:
        posicaoCrescente = i
        break

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime o vetor em ordem crescente
print("\nVetor Crescente: [", end="")
for i in range(tamanho):
    print(vetorCrescente[i], end="")
    if i < tamanho - 1:
        print("  ", end="")
print("]")

# Procura a posição do número quando o vetor está em ordem decrescente
posicaoDecrescente = -1
vetorDecrescente = vetor.copy()
ordenar_decrescente(vetorDecrescente)  # Ordena em ordem decrescente

for i in range(tamanho):
    if vetorDecrescente[i] == numero:
        posicaoDecrescente = i
        break

# Imprime o vetor em ordem decrescente
print("\nVetor Decrescente: [", end="")
for i in range(tamanho):
    print(vetorDecrescente[i], end="")
    if i < tamanho - 1:
        print("  ", end="")
print("]")

# Imprime a posição do número nas duas ordens
if posicaoCrescente != -1:
    print("\nPosição do número {} em ordem crescente: {}".format(numero, posicaoCrescente))
else:
    print("\nO número {} não foi encontrado em ordem crescente.".format(numero))

if posicaoDecrescente != -1:
    print("Posição do número {} em ordem decrescente: {}".format(numero, posicaoDecrescente))
else:
    print("O número {} não foi encontrado em ordem decrescente.".format(numero))

print("\nObrigado por utilizar nosso programa!\n")
os.system ("Pause")
