import os
class ContagemLetras:
    def main(self):
        print("\nEste programa lê textos por linha. Após exibir o texto, o programa determina a quantidade de uma determinada letra digitada!")
        texto = input("\nDigite um texto (até 999 caracteres): ")

        print("\nTexto digitado: " + texto)

        letra = input("\nDigite uma letra para contar sua ocorrência no texto: ")[0]

        contador = 0
        for i in range(len(texto)):
            if texto[i] == letra:
                contador += 1

        print("\nA letra '" + letra + "' ocorre " + str(contador) + " vezes no texto.")
        print("\nObrigado por utilizar nosso programa!")

if __name__ == "__main__":
    contagem_letras = ContagemLetras()
    contagem_letras.main()

os.system("Pause")
