import os
print("\nEste programa determina os elementos de A!\n")

# Solicita ao usuário o tamanho do vetor B
tamanhoB = int(input("Informe o tamanho do vetor B: "))

# Declaração e alocação do vetor B
vetorB = []

# Leitura dos elementos do vetor B
print("\nInforme os elementos do vetor B: ")
for i in range(tamanhoB):
    elemento = int(input("Elemento [{}]: ".format(i)))
    vetorB.append(elemento)

# Solicita ao usuário o tamanho do vetor C
tamanhoC = int(input("\nInforme o tamanho do vetor C: "))

# Declaração e alocação do vetor C
vetorC = []

# Leitura dos elementos do vetor C
print("\nInforme os elementos do vetor C: ")
for i in range(tamanhoC):
    elemento = int(input("Elemento [{}]: ".format(i)))
    vetorC.append(elemento)

# Vetor A terá o tamanho do maior entre B e C
tamanhoA = max(tamanhoB, tamanhoC)

# Declaração e alocação do vetor A
vetorA = []

# Verifica se os tamanhos de B e C são iguais
tamanhosIguais = tamanhoB == tamanhoC

if tamanhosIguais:
    # Calcula o vetor A se os tamanhos de B e C forem iguais
    for i in range(tamanhoA):
        vetorA.append(vetorC[i] - vetorB[i])

print("\n\n\n")
input("Pressione Enter para continuar...")

# Imprime os três vetores
print("\nVetor B: [", end="")
for i in range(tamanhoB):
    print(vetorB[i], end="")
    if i < tamanhoB - 1:
        print("  ", end="")
print("]")

print("\nVetor C: [", end="")
for i in range(tamanhoC):
    print(vetorC[i], end="")
    if i < tamanhoC - 1:
        print("  ", end="")
print("]")

if tamanhosIguais:
    print("\nVetor A: [", end="")
    for i in range(tamanhoA):
        print(vetorA[i], end="")
        if i < tamanhoA - 1:
            print("  ", end="")
    print("]")
else:
    print("\n\nNão é possível calcular a soma dos vetores devido a tamanhos diferentes.\n")

print("\n\nObrigado por utilizar nosso programa!\n")
os.system ("Pause")
