import os

print("\n\nEste programa realiza a multiplicação de duas matrizes quadradas de ordem n, imprime as duas matrizes originais, a matriz resultado e carrega um vetor com os elementos da diagonal secundária!")

n = int(input("\n\nInforme a ordem da matriz quadrada: "))

A = [[0] * n for _ in range(n)]
B = [[0] * n for _ in range(n)]
C = [[0] * n for _ in range(n)]

print("\n\nInforme os elementos da matriz A:")
for i in range(n):
    for j in range(n):
        A[i][j] = int(input())

print("\n\nInforme os elementos da matriz B:")
for i in range(n):
    for j in range(n):
        B[i][j] = int(input())

for i in range(n):
    for j in range(n):
        C[i][j] = 0
        for k in range(n):
            C[i][j] += A[i][k] * B[k][j]

print("\n\nMatriz A:")
for i in range(n):
    for j in range(n):
        print(A[i][j], end=" ")
    print()

print("\n\nMatriz B:")
for i in range(n):
    for j in range(n):
        print(B[i][j], end=" ")
    print()

print("\n\nMatriz Resultado (C):")
for i in range(n):
    for j in range(n):
        print(C[i][j], end=" ")
    print()

diagonalSecundaria = [C[i][n - 1 - i] for i in range(n)]

print("\n\nElementos da diagonal secundária de C:")
for element in diagonalSecundaria:
    print(element, end=" ")
print("\n\nObrigado por utilizar nosso programa!")

os.system("Pause")
