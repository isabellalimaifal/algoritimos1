#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale(LC_ALL, "Portuguese");
	int num, n, i, j, fatorial = 1;
	printf ("\n\nEste programa calcula o fatorial de um n�mero inteiro n�o negativo!");
	printf ("\n\nInforme a quantidade de n�meros inteiros n�o negativos para c�lculo de fatorial: ");
	scanf ("%d", &n);
	if (n > 0) {
		i = 1;
		while (i <= n) {
			printf ("\n\n\nInforme o %d� n�mero para c�lculo de fatorial: ", i);
			scanf ("%d", &num);
			if (num < 0)
				num = num * (-1);
			fatorial = 1;
			for (j = num; j > 0; j--) {
				fatorial *= j; //fatorial = fatorial * num
			}
			printf ("\n\n\nResultado: %d! = %d.", num, fatorial);
			i++;
		}
	}
	else
		printf ("\n\nInforme uma quantidade v�lida de n�meros!");
	printf ("\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
