//Resolvendo utilizando while()
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale(LC_ALL, "Portuguese");
	int termo1, termo2, novoTermo, n, i;
	printf ("\n\nEste programa imprime a S�rie de Fibonacci at� o n� termo!");
	printf ("\n\nInforme o termo n para impress�o da s�rie: ");
	scanf ("%d", &n);
	if (n <= 0) {
		printf ("\n\nInforme um valor v�lido para impress�o da S�rie de Fibonacci");
	}
	else if (n == 1) {
		printf ("\n\nS�rie de Fibonacci: 1, ");
	}
	else if (n > 1) {
		termo1 = 1;
		termo2 = 1;
		printf ("\n\nS�rie de Fibonacci: %d, %d, ", termo1, termo2);
		i = 2;
		while (i < n) {
			novoTermo = termo1 + termo2;
			printf ("%d, ", novoTermo);
			termo1 = termo2;
			termo2 = novoTermo;
			i++;
		}
	}
	printf ("...");
	printf ("\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
