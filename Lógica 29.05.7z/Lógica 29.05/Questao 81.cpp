#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale(LC_ALL, "Portuguese");
	float aresta, volCubo = 1.0, volTotal = 0.0;
	int i, n;
	printf ("\n\nEste programa calcula o volume de n cubos de m�tricas diferentes!");
	printf ("\n\nInforme a quantidade de cubos para c�lulo de volume: ");
	scanf ("%d", &n);
	i = 1;
	if (n > 0) {
		do {
			printf ("\n\nInforme o valor da aresta (m) do %d� cubo: ", i);
			scanf ("%f", &aresta);
			volCubo = (aresta * aresta) * aresta;
			printf ("\n\nO volume do %d� cubo � de %.2f metros c�bicos!", i, volCubo);
			volTotal += volCubo; //volTotal = volTotal + volCubo	
			i++;
		} while (i <= n);
		printf ("\n\nO volume total dos %d cubo � de %.2f metros c�bicos!", n, volTotal);
	}	
	else
		printf ("\n\nInforme um valor v�lido!");
	printf ("\n\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
