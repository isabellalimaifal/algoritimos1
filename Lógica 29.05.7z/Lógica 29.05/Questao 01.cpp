#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale(LC_ALL, "Portuguese");
	float tMinutos, tSegundos = 0.0, tHoras = 0.0;
	printf ("\n\nEste programa transforma um tempo minutos em horas e segundos!");
	printf ("\n\nInforme o tempo em minutos: ");
	scanf ("%f", &tMinutos);
	tSegundos = tMinutos * 60.0;
	tHoras = tMinutos /60.0;
	printf ("\n\nTempo digitado em minutos: %.2f!", tMinutos);
	printf ("\n\nTempo convertido em segundos: %.2f!", tSegundos);
	printf ("\n\nTempo convertido em horas: %.2f!", tHoras);  
	printf ("\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
