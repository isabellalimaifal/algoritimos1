#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) {
	system ("cls");
	setlocale(LC_ALL, "Portuguese");
	float t1, t2, p1, p2, vMedia = 0.0;
	printf ("\n\nEste programa determina a velocidade m�dia de um m�vel em movimento uniforme (km/h)!");
	printf ("\n\nInforme o tempo inicial (h): ");
	scanf ("%f", &t1);
	printf ("\n\nInforme o espa�o inicial (km): ");
	scanf ("%f", &p1);
	printf ("\n\nInforme o tempo final (h): ");
	scanf ("%f", &t2);
	printf ("\n\nInforme o espa�o final (km): ");
	scanf ("%f", &p2);
	vMedia = (p2 - p1) / (t2 - t1);
	printf ("\n\nA velocidade m�dia do m�vel � de %.2f km/h!", vMedia);
	printf ("\n\nObrigado por utilizar nosso programa!\n\n");
	system ("Pause");
	return 0;
}
